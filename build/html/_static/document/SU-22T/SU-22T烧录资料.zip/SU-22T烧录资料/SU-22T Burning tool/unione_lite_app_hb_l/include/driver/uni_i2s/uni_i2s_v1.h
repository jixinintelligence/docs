/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : uni_i2s_v1.h
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/
#ifndef __UNI_I2S_V1_H__
#define __UNI_I2S_V1_H__

/**
 * @brief I2S模块
 */
typedef enum {
	MODULE_I2S_IN,
	MODULE_REC_OUT,
	MODULE_I2S_OUT
} UNI_I2S_MODULE;

/**
 * @brief I2S单一模式
 */
typedef enum {
	I2S_MODE_SLAVE,
	I2S_MODE_MASTER,
} UNI_I2S_SINGLE_MODE;

/**
 * @brief I2S五线模式
 */
typedef enum {
	I2S_MODE_I2S_IN_M_REC_OUT_S,
	I2S_MODE_I2S_IN_S_REC_OUT_M,
	I2S_MODE_I2S_IN_S_REC_OUT_S_FROM_I2S_IN,
	I2S_MODE_I2S_IN_S_REC_OUT_S_FROM_REC_OUT,

	I2S_MODE_I2S_IN_M_I2S_OUT_S,
	I2S_MODE_I2S_IN_S_I2S_OUT_M,
	I2S_MODE_I2S_IN_S_I2S_OUT_S_FROM_I2S_IN,
	I2S_MODE_I2S_IN_S_I2S_OUT_S_FROM_I2S_OUT,

	I2S_MODE_REC_OUT_M_I2S_OUT_S,
	I2S_MODE_REC_OUT_S_I2S_OUT_M,
	I2S_MODE_REC_OUT_S_I2S_OUT_S_FROM_REC_OUT,
	I2S_MODE_REC_OUT_S_I2S_OUT_S_FROM_I2S_OUT,
} UNI_I2S_FIVE_WIRE_MODE;

/**
 * @brief I2S MCLK类型
 */
typedef enum {
	I2S_IN_MCLK_IN,
	I2S_IN_MCLK_OUT,
	REC_OUT_MCLK_IN,
	REC_OUT_MCLK_OUT,
	I2S_OUT_MCLK_IN,
} UNI_I2S_MCLK_TYPE;

/**
 * @brief I2S BCLK类型
 */
typedef enum {
	I2S_IN_BCLK_IN,
	I2S_IN_BCLK_OUT,
	REC_OUT_BCLK_IN,
	REC_OUT_BCLK_OUT,
	I2S_OUT_BCLK_IN,
	I2S_OUT_BCLK_OUT
} UNI_I2S_BCLK_TYPE;

/**
 * @brief I2S LRCLK类型
 */
typedef enum {
	I2S_IN_LRCLK_IN,
	I2S_IN_LRCLK_OUT,
	REC_OUT_LRCLK_IN,
	REC_OUT_LRCLK_OUT,
	I2S_OUT_LRCLK_IN,
	I2S_OUT_LRCLK_OUT
} UNI_I2S_LRCLK_TYPE;

/**
 * @brief 设置单一I2S工作模式
 *
 * @param module i2s 模块
 * @param mode   工作模式
 *
 * @return int 设置是否成功
 * @retval  0 成功
 * @retval -1 失败
 */
int uni_i2s_set_single_mode(UNI_I2S_MODULE module, UNI_I2S_SINGLE_MODE mode);

/**
 * @brief 设置五线I2S工作模式
 *
 * @param mode  工作模式
 *
 * @return int 设置是否成功
 * @retval  0 成功
 * @retval -1 失败
 */
int uni_i2s_set_five_wire_mode(UNI_I2S_FIVE_WIRE_MODE mode);
#endif
