/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : lvp_audio_in.h
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/

#ifndef __LVP_AUDIO_IN_H__
#define __LVP_AUDIO_IN_H__

#include <lvp_context.h>

typedef int (*AUDIO_IN_RECORD_CALLBACK)(int ctx_index, void *priv);

int LvpAudioInUpdateReadIndex(int offset);
int LvpGetAudioInCtrlVad(void);
int LvpSetAudioInCtrlVad(int vad);
int LvpGetAudioInCtrlStartCtxIndex(void);
int LvpAudioInInit(AUDIO_IN_RECORD_CALLBACK callback);
int LvpAudioInQueryFFTVad(unsigned int *sdc_addr);
int LvpAuidoInQueryEnvNoise(LVP_CONTEXT *context);
void LvpAudioInSuspend(void);
void LvpAudioInResume(void);
int LvpAudioInDone(void);

#endif /* __LVP_AUDIO_IN_H__ */
