/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : soc_config.h
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/

#ifndef __SOC_CONFIG_H__
#define __SOC_CONFIG_H__

#include <autoconf.h>
#include <base_addr.h>

/*
 * Memory configurations
 */
#define CONFIG_SET_MEM_PARAM

// Sram total size
#define CONFIG_NPU_SRAM_SIZE       (CONFIG_NPU_SRAM_SIZE_KB * 1024)

#define CONFIG_AUDIO_OUT_BUFFER_SIZE      (CONFIG_AUDIO_OUT_BUFFER_SIZE_KB * 1024)

#define CONFIG_MCU_SRAM_SIZE       (0x30000 - CONFIG_NPU_SRAM_SIZE - CONFIG_AUDIO_OUT_BUFFER_SIZE)
#define CONFIG_AUDIO_IN_SRAM_SIZE  0x4000

#define CONFIG_TOTAL_SRAM_SIZE     (0x20000/*npu*/ + 0x10000/*mcu*/ + 0x4000/*audio in*/)

// Stage1 size
#define CONFIG_STAGE1_SRAM_SIZE    0x3000
#define CONFIG_STAGE1_IRAM_SIZE    0x3000
#define CONFIG_STAGE1_DRAM_SIZE    0x3000

// Stage2 size
#define CONFIG_STAGE2_SRAM_SIZE    CONFIG_MCU_SRAM_SIZE
#define CONFIG_STAGE2_IRAM_SIZE    CONFIG_STAGE2_SRAM_SIZE
#define CONFIG_STAGE2_DRAM_SIZE    CONFIG_STAGE2_SRAM_SIZE
#define CONFIG_STAGE2_XIP_SIZE     0x100000 // 1M flash for .stage2_text segment

// Stage1 addr
#define CONFIG_STAGE1_IRAM_BASE    0x10000000
#define CONFIG_STAGE1_DRAM_BASE    0x20000000

// Stage2 addr
#define CONFIG_STAGE2_IRAM_BASE    (CONFIG_STAGE1_IRAM_BASE + CONFIG_NPU_SRAM_SIZE)
#define CONFIG_STAGE2_XIP_BASE     (CONFIG_FLASH_XIP_BASE + CONFIG_STAGE1_IRAM_SIZE)
#define CONFIG_STAGE2_DRAM_BASE    (CONFIG_STAGE1_DRAM_BASE + CONFIG_NPU_SRAM_SIZE)

#define CONFIG_ALL_BIN_SIZE        (CONFIG_STAGE1_SRAM_SIZE + CONFIG_STAGE2_SRAM_SIZE)
#define CONFIG_DRAM_BASE           0x50000000

#define CONFIG_SYS_MALLOC_BASE     (CONFIG_STAGE2_DRAM_BASE + CONFIG_STAGE2_DRAM_SIZE)

#ifdef CONFIG_BOOT_TOOL
#define CONFIG_SRAM_RESERVR_SIZE   0x0
#else
#define CONFIG_SRAM_RESERVR_SIZE   0x0
#endif
#define CONFIG_SYS_MALLOC_LEN      (CONFIG_MCU_SRAM_SIZE - CONFIG_STAGE2_DRAM_SIZE - CONFIG_SRAM_RESERVR_SIZE)

#define CONFIG_STAGE1_STACK        (CONFIG_STAGE1_DRAM_BASE + CONFIG_STAGE1_DRAM_SIZE - 4)
#define CONFIG_STAGE2_STACK        (CONFIG_STAGE2_DRAM_BASE + CONFIG_STAGE2_DRAM_SIZE - 4)


#endif /* __SOC_CONFIG_H__ */
