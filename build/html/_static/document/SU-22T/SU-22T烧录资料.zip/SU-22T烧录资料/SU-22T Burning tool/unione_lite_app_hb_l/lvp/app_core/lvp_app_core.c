/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : lvp_app_core.c
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/

#include <autoconf.h>

#include <stdio.h>
#include <string.h>

#include <lvp_buffer.h>
#include <board_config.h>

#ifndef USE_MP3
#include "lvp_voice_player.h"
#else
#include "lvp_mp3_player.h"
#endif

#include "lvp_pmu.h"
#include "lvp_queue.h"
#include "lvp_app_core.h"
#include "lvp_app.h"

#ifdef CONFIG_UNI_UART_RECORD
#include "uni_uart_record.h"
#endif
#include "uni_cust_config.h"

#define LOG_TAG "[APP_EVENT]"

__attribute__((weak)) LVP_APP *app_core_ops = NULL;
//=================================================================================================

#define LVP_APP_MISC_QUEUE_LEN 8
static unsigned char s_app_misc_event_queue_buffer[LVP_APP_MISC_QUEUE_LEN * sizeof(APP_EVENT)] = {0};
LVP_QUEUE s_app_misc_event_queue;

#ifdef CONFIG_UNI_UART_RECORD
#define LVP_APP_ENABLE_AIN_CB_EVENT
#endif
#ifdef LVP_APP_ENABLE_AIN_CB_EVENT
#define LVP_APP_AIN_CB_QUEUE_LEN 3
static unsigned char s_app_ain_cb_event_queue_buffer[LVP_APP_AIN_CB_QUEUE_LEN * sizeof(APP_EVENT)] = {0};
LVP_QUEUE s_app_ain_cb_event_queue;
#endif

//=================================================================================================
int LvpTriggerAppEvent(APP_EVENT *app_event)
{
    LvpQueuePut(&s_app_misc_event_queue, (const unsigned char *)app_event);

#ifdef LVP_APP_ENABLE_AIN_CB_EVENT
    if (app_event->event_id == AUDIO_IN_RECORD_DONE_EVENT_ID) {
        LvpQueuePut(&s_app_ain_cb_event_queue, (const unsigned char *)app_event);
    }
#endif

    return 0;
}

static int _LvpAppSuspend(void *priv)
{
    if ((app_core_ops) && (app_core_ops->AppSuspend)) {
        app_core_ops->AppSuspend(app_core_ops->suspend_priv);
    }
    return 0;
}

static int _LvpAppResume(void *priv)
{
    if((app_core_ops) && (app_core_ops->AppResume)) {
        app_core_ops->AppResume(app_core_ops->resume_priv);
    }
    return 0;
}

int LvpInitializeAppEvent(void)
{
    LvpQueueInit(&s_app_misc_event_queue, s_app_misc_event_queue_buffer, LVP_APP_MISC_QUEUE_LEN * sizeof(APP_EVENT), sizeof(APP_EVENT));
#ifdef LVP_APP_ENABLE_AIN_CB_EVENT
    LvpQueueInit(&s_app_ain_cb_event_queue, s_app_ain_cb_event_queue_buffer, LVP_APP_AIN_CB_QUEUE_LEN * sizeof(APP_EVENT), sizeof(APP_EVENT));
#endif
    if((app_core_ops) && (app_core_ops->AppInit))
        app_core_ops->AppInit();

    LVP_SUSPEND_INFO suspend_info = {
        .suspend_callback = _LvpAppSuspend,
        .priv = "_LvpAppSuspend"
    };

    LVP_RESUME_INFO resume_info = {
        .resume_callback = _LvpAppResume,
        .priv = "_LvpAppResume"
    };
    LvpSuspendInfoRegist(&suspend_info);
    LvpResumeInfoRegist(&resume_info);

    return 0;
}

int LvpAppEventTick(void)
{
    APP_EVENT app_event = {.event_id = 0};

    if (LvpQueueGet(&s_app_misc_event_queue, (unsigned char *)&app_event)) {
        if((app_core_ops) && (app_core_ops->AppEventResponse))
            app_core_ops->AppEventResponse(&app_event);
    }

#ifdef LVP_APP_ENABLE_AIN_CB_EVENT
    if (LvpQueueGet(&s_app_ain_cb_event_queue, (unsigned char *)&app_event)) {
#ifdef CONFIG_UNI_UART_RECORD
      if (UniUartRecordisStart() == 1) {
        LVP_CONTEXT *context;
        unsigned int ctx_size;
        LvpGetContext(app_event.ctx_index, &context, &ctx_size);
        UniUartRecordTask(context);
      }
#endif
    }
#endif

    if((app_core_ops) && (app_core_ops->AppTaskLoop)) {
        app_core_ops->AppTaskLoop();
    }

#if UNI_REPLY_TYPE == UNI_REPLY_TYPE_SPEAKER
#ifndef USE_MP3
    LvpVoicePlayerTask(NULL);
#else
    LvpMp3PlayerTask(NULL);
#endif
#endif

    return 0;
}


