/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : lvp_mode.h
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/

#ifndef __LVP_MODE_H__
#define __LVP_MODE_H__

typedef enum {
    LVP_MODE_IDLE,
    LVP_MODE_RECORD,
    LVP_MODE_FEED,
    LVP_MODE_KWS
} LVP_MODE_TYPE;

typedef int  (*LVP_MODE_INIT)(LVP_MODE_TYPE prev_mode);
typedef void (*LVP_MODE_DONE)(LVP_MODE_TYPE next_mode);
typedef void (*LVP_MODE_TICK)(void);
typedef struct {
    LVP_MODE_TYPE   type;
    LVP_MODE_INIT   init;
    LVP_MODE_DONE   done;
    LVP_MODE_TICK   tick;
} LVP_MODE_INFO;

LVP_MODE_TYPE LvpInitMode(LVP_MODE_TYPE mode);
LVP_MODE_TYPE LvpSwitchMode(LVP_MODE_TYPE mode);
LVP_MODE_TYPE LvpGetCurrentMode(void);

int LvpModeTick(void);
void LvpExit(void);

#endif /* __LVP_MODE_H__ */
