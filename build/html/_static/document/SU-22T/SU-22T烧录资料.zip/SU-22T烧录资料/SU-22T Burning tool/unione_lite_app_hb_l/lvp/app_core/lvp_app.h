/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : lvp_app.h
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/

#ifndef __LVP_APP_H__
#define __LVP_APP_H__

#include "lvp_app_core.h"

typedef struct {
    const char *app_name;
    int (*AppInit)(void);
    int (*AppEventResponse)(APP_EVENT *plc_event);
    int (*AppTaskLoop)(void);
    int (*AppSuspend)(void *priv);
    void *suspend_priv;
    int (*AppResume)(void *priv);
    void *resume_priv;
}LVP_APP;

#define LVP_REGISTER_APP(app)    \
    LVP_APP *app_core_ops = &app

#endif // __LVP_APP_H__
