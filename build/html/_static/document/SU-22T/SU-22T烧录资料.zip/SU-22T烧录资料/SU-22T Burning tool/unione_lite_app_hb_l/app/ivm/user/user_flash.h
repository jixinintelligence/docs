/**************************************************************************
 * Copyright (C) 2017-2017  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : user_flash.h
 * Author      : yuanshifeng@unisound.com
 * Date        : 2021.10.23
 *
 **************************************************************************/
#ifndef USER_FLASH_H_
#define USER_FLASH_H_

#include "driver/uni_flash.h"
#include "lvp_app_core.h"

/* !!! last 4K-sector is not avaliable !!!
 * addr range 0x00000000 ~ chip_size ( can be found in user_flash_init() )
 * pls make sure code&data cannot overlap user-flash start address */
   
int user_flash_init(void);
int user_flash_read(unsigned int addr, unsigned char *data, unsigned int len);
int user_flash_write(unsigned int addr, unsigned char *data, unsigned int len);

/* erase addr&len should be (n * erase_size) bytes */
int user_flash_erase(unsigned int addr, unsigned int len);

void user_flash_test(void);

#endif
