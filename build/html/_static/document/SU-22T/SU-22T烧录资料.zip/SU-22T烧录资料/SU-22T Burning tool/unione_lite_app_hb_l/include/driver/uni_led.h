/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : uni_led.h
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/
#ifndef __UNI_LED_H__
#define __UNI_LED_H__

/**
 * @brief led开关状态
 */
typedef enum {
	UNI_LED_SWITCH_OFF = 0, ///< led关闭
	UNI_LED_SWITCH_ON,      ///< led打开
} UNI_LED_SWITCH;

/**
 * @brief led亮度等级
 */
typedef enum {
	UNI_LED_LIGHT_0 = 0x06, ///< led亮度等级0
	UNI_LED_LIGHT_1 = 0x04, ///< led亮度等级1
	UNI_LED_LIGHT_2 = 0x02, ///< led亮度等级2
	UNI_LED_LIGHT_3 = 0x00, ///< led亮度等级3
} UNI_LED_LIGHT;

/**
 * @brief led pwm频率
 */
typedef enum {
	UNI_LED_FRE_3K = 0, ///< pwm频率3KHz
	UNI_LED_FRE_22K,    ///< pwm频率22KHz
} UNI_LED_FRE_SET;

/**
 * @brief led颜色
 */
typedef struct {
	unsigned char r; ///< led绿色分量
	unsigned char b; ///< led蓝色分量
	unsigned char g; ///< led绿色分量
} UNI_LED_COLOR;

/**
 * @brief 设置led颜色
 *
 * @param index_v led id
 * @param rbg led颜色分量
 *
 * @retval 0 成功
 * @retval -1 失败
 */
int uni_led_set_color(int index_v, UNI_LED_COLOR rbg);

/**
 * @brief 设置led亮度
 *
 * @param index_v led id
 * @param light led亮度等级
 *
 * @retval 0 成功
 * @retval -1 失败
 */
int uni_led_set_light(int index_v, UNI_LED_LIGHT light);

/**
 * @brief 设置led开关
 *
 * @param index_v led id
 * @param val led开关状态
 *
 * @retval 0 成功
 * @retval -1 失败
 */
int uni_led_switch(int index_v, UNI_LED_SWITCH val);

/**
 * @brief 设置led进入shutdown
 *
 * @param 无
 *
 * @retval 0 成功
 * @retval -1 失败
 */
int uni_led_enable(void);

/**
 * @brief 设置led退出shutdown
 *
 * @param 无
 *
 * @retval 0 成功
 * @retval -1 失败
 */
int uni_led_disable(void);

/**
 * @brief 设置led复位
 *
 * @param 无
 *
 * @retval 0 成功
 * @retval -1 失败
 */
int uni_led_reset(void);

/**
 * @brief 设置led pwm频率
 *
 * @param val pwm频率值
 *
 * @retval 0 成功
 * @retval -1 失败
 */
int uni_led_set_frequency(UNI_LED_FRE_SET val);

/**
 * @brief 初始化led
 *
 * @param i2c_bus i2c总线id
 *
 * @retval 0 成功
 * @retval -1 失败
 */
int uni_led_init(int i2c_bus);

#endif
