/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : uni_spinor.h
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/
#ifndef __UNI_SPINOR_H__
#define __UNI_SPINOR_H__

int uni_spi_nor_init(int bus_num,int cs, int speed, int mode);
void uni_spi_nor_protect_init(void);
int uni_spi_nor_fast_readdata(unsigned int from, unsigned char *buf,unsigned int len);
int uni_spi_nor_dual_readdata(unsigned int from, unsigned char *buf,unsigned int len);
int uni_spi_nor_readdata(unsigned int from, unsigned char *buf, unsigned int len);
int uni_spi_nor_pageprogram(unsigned int to,unsigned char *buf,unsigned int len);
int uni_spi_nor_chiperase(void);
int uni_spi_nor_erasedata(unsigned int addr, unsigned int len);
void uni_spi_nor_sync(void);

void uni_spi_nor_exit_4byte(void);
char *uni_spi_nor_gettype(void);
unsigned int uni_spi_nor_get_info(enum uni_flash_info flash_info);

int uni_spi_nor_write_protect_mode(void);
int uni_spi_nor_write_protect_status(unsigned int *len);
int uni_spi_nor_write_protect_lock(unsigned int protect_addr);
int uni_spi_nor_write_protect_unlock(void);
int uni_spi_nor_set_lock_reg(void);
int uni_spi_nor_get_lock_reg(int *lock);
void uni_spi_nor_calcblockrange(unsigned int addr, unsigned int len, unsigned int *pstart, unsigned int *pend);

int uni_spi_nor_otp_status(unsigned char *buf);
int uni_spi_nor_otp_lock(void);
int uni_spi_nor_otp_read(unsigned int addr, unsigned char *buf, unsigned int len);
int uni_spi_nor_otp_write(unsigned int addr, unsigned char *buf, unsigned int len);
int uni_spi_nor_otp_erase(void);
int uni_spi_nor_otp_get_region(unsigned int *region);
int uni_spi_nor_otp_set_region(unsigned int region);

#endif
