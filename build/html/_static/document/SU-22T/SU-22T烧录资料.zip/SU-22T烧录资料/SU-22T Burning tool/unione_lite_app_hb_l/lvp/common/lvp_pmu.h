/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : lvp_pmu.h
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/

#ifndef __LVP_PMU_H__
#define __LVP_PMU_H__

typedef int (*LVP_SUSPEND_CALLBACK)(void *priv);
typedef int (*LVP_RESUME_CALLBACK)(void *priv);

typedef struct {
    LVP_SUSPEND_CALLBACK suspend_callback;
    void *priv;
} LVP_SUSPEND_INFO;

typedef struct {
    LVP_RESUME_CALLBACK resume_callback;
    void *priv;
} LVP_RESUME_INFO;

typedef enum {
    LRT_GPIO     =   0x01,
    LRT_RTC      =   0x02,
    LRT_AUDIO_IN =   0x04,
    LRT_I2C      =   0x08,
} LVP_RESUME_TYPE;


int LvpPmuInit(void);

int LvpSuspendInfoRegist(LVP_SUSPEND_INFO *suspend_info);

int LvpResumeInfoRegist(LVP_RESUME_INFO *resume_info);

int LvpPmuSuspendLockCreate(int *lock);

int LvpPmuSuspendLockDestory(int lock);

int LvpPmuSuspendLock(int lock);

int LvpPmuSuspendUnlock(int lock);

int LvpPmuSuspendIsLocked(void);

int LvpPmuSuspend(int type); // LVP_RESUME_TYPE

int LvpPmuPowerOff(void);

int LvpPmuResume(void);


#endif /* __LVP_PMU_H__ */

