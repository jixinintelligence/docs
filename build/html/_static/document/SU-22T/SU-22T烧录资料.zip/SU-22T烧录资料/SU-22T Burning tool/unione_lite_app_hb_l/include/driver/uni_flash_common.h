/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : uni_flash_common.h
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/
#ifndef __UNI_FLASH_COMMON_H__
#define __UNI_FLASH_COMMON_H__

/**
 * @brief 3 types of flash
 */
enum {
	UNI_FLASH_CHIP_TYPE_NOR = 0,
	UNI_FLASH_CHIP_TYPE_SPINAND,
	UNI_FLASH_CHIP_TYPE_NAND,
	UNI_FLASH_CHIP_TYPE_UNKNOWN
};

/**
 * @brief flash protect mode
 */
enum {
	UNI_FLASH_PROTECT_MODE_NONSUPPORT = 0,
	UNI_FLASH_PROTECT_MODE_BOTTOM,
	UNI_FLASH_PROTECT_MODE_TOP
};

/**
 * @brief flash match mode
 */
enum {
	UNI_FLASH_MATCH_MODE_NONSUPPORT = 0,
	UNI_FLASH_MATCH_MODE_ID,
	UNI_FLASH_MATCH_MODE_BLUR
};

/**
 * @brief flash信息
 */
enum uni_flash_info {
	UNI_FLASH_CHIP_TYPE,
	UNI_FLASH_CHIP_NAME,
	UNI_FLASH_CHIP_ID,
	UNI_FLASH_CHIP_SIZE,
	UNI_FLASH_BLOCK_SIZE,
	UNI_FLASH_BLOCK_NUM,
	UNI_FLASH_SECTOR_SIZE,
	UNI_FLASH_SECTOR_NUM,
	UNI_FLASH_PAGE_SIZE,
	UNI_FLASH_PAGE_NUM,
	UNI_FLASH_ERASE_SIZE,
	UNI_FLASH_ERASE_NUM,
	UNI_FLASH_PROTECT_MODE,
	UNI_FLASH_MATCH_MODE,
};

#endif /* __UNI_FLASH_COMMON_H__ */

