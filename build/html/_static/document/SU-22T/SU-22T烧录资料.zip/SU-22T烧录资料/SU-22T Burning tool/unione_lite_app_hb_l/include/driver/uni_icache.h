/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : uni_icache.h
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/
#ifndef __UNI_ICACHE_H__
#define __UNI_ICACHE_H__

#include <common.h>
#include <soc.h>

/**
 * @brief 使能 icache
 */
void uni_icache_enable(void);

/**
 * @brief 关闭 icache
 */
void uni_icache_disable(void);

/**
 * @brief 使能 icache 信息统计
 */
void uni_icache_enable_profile(void);

/**
 * @brief 关闭 icache 信息统计
 */
void uni_icache_disable_profile(void);

/**
 * @brief icache 信息统计数据清零
 */
void uni_icache_reset_profile(void);

/**
 * @brief 获取 icache 命中次数
 *
 * @return uint32_t icache 命中次数
 */
uint32_t uni_icache_get_access_time(void);

/**
 * @brief 获取 icache 不命中次数
 *
 * @return uint32_t icache 不命中次数
 */
uint32_t uni_icache_get_miss_time(void);

/**
 * @brief 初始化 icache
 */
void uni_icache_init(void);

#endif
