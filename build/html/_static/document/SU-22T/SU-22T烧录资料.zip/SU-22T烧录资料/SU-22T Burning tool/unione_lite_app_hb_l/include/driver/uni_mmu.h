/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : uni_mmu.h
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/
#ifndef __UNI_MMU_H__
#define __UNI_MMU_H__

#include <stdint.h>

/**
 * @brief mmu 地址映射
 *
 * @param virt_addr 虚拟地址
 * @param phy_addr 物理地址
 * @param size 映射大小
 *
 * @return int 映射是否成功
 * @retval 0 成功
 * @retval -1 失败
 */
int uni_mmu_map(uint32_t virt_addr, uint32_t phy_addr, size_t size);

/**
 * @brief mmu 地址解除映射
 *
 * @param virt_addr 要解除映射的虚拟首地址
 *
 * @return int 解除映射是否成功
 * @retval 0 成功
 * @retval -1 失败
 */
int uni_mmu_unmap(uint32_t virt_addr);

#endif
