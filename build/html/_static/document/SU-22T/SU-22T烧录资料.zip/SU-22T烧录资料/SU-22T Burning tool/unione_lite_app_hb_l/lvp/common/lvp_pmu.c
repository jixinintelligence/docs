/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : lvp_pmu.c
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/

#include <autoconf.h>
#include <stdio.h>
#include <driver/uni_pmu_ctrl.h>
#include <driver/uni_audio_in.h>
#include <driver/uni_npu.h>
#include <driver/uni_irq.h>

#include <lvp_audio_in.h>
#include <lvp_app_core.h>
#include <lvp_pmu.h>
#include <lvp_queue.h>

#define LOG_TAG "[PMU]"

#define SUSPEND_INFO_NUM 8
#define RESUME_INFO_NUM 8

typedef struct {
    unsigned int suspend_lock;
    unsigned int suspend_lock_mask;
    unsigned int s_suspend_info_num;
    unsigned int s_resume_info_num;
    LVP_SUSPEND_INFO s_suspend_info_buffer[SUSPEND_INFO_NUM];
    LVP_RESUME_INFO s_resume_info_buffer[RESUME_INFO_NUM];
} LVP_STANDBY_HANDLE;

static LVP_STANDBY_HANDLE s_handle;

int LvpPmuInit(void)
{
    UNI_WAKEUP_SOURCE start_mode = uni_pmu_get_wakeup_source();
    if (start_mode == UNI_WAKEUP_SOURCE_COLD || start_mode == UNI_WAKEUP_SOURCE_WDT) {
        memset((void *)&s_handle, 0, sizeof(LVP_STANDBY_HANDLE));
        return 1;
    } else {
        for (int i = 0; i < s_handle.s_resume_info_num; i++) {
            s_handle.s_resume_info_buffer[i].resume_callback(s_handle.s_resume_info_buffer[i].priv);
        }
        return 0;
    }

}

int LvpSuspendInfoRegist(LVP_SUSPEND_INFO *suspend_info)
{
    for(int i = 0; i < SUSPEND_INFO_NUM; i++) {
        if(s_handle.s_suspend_info_buffer[i].suspend_callback == suspend_info->suspend_callback) {
            memcpy((void *)&s_handle.s_suspend_info_buffer[s_handle.s_suspend_info_num], \
                   (const void *)suspend_info, sizeof(LVP_SUSPEND_INFO));
            return 0;
        }
    }

    if (s_handle.s_suspend_info_num < SUSPEND_INFO_NUM && suspend_info->suspend_callback != NULL) {
        memcpy((void *)&s_handle.s_suspend_info_buffer[s_handle.s_suspend_info_num], \
               (const void *)suspend_info, sizeof(LVP_SUSPEND_INFO));
        s_handle.s_suspend_info_num++;
    } else {
        return -1;
    }

    return 0;
}

int LvpResumeInfoRegist(LVP_RESUME_INFO *resume_info)
{
    for(int i = 0; i < RESUME_INFO_NUM; i++) {
        if(s_handle.s_resume_info_buffer[i].resume_callback == resume_info->resume_callback) {
            memcpy((void *)&s_handle.s_resume_info_buffer[s_handle.s_resume_info_num], \
                   (const void *)resume_info, sizeof(LVP_RESUME_INFO));
            return 0;
        }
    }

    if (s_handle.s_resume_info_num < RESUME_INFO_NUM && resume_info->resume_callback != NULL) {
        memcpy((void *)&s_handle.s_resume_info_buffer[s_handle.s_resume_info_num], \
               (const void *)resume_info, sizeof(LVP_RESUME_INFO));
        s_handle.s_resume_info_num++;
    } else {
        return -1;
    }

    return 0;
}

int LvpPmuSuspendLockCreate(int *lock)
{
    for (int i = 0; i < 32; i++) {
        if (!(s_handle.suspend_lock_mask & (0x1 << i))) {
            *lock = i + 1;
            s_handle.suspend_lock_mask |= (0x1 << i);
            return *lock;
        }

        if (i == 32)
            return -1;
    }

    return -1;
}

int LvpPmuSuspendLockDestory(int lock)
{

    if (lock > 0 && lock <= 32) {
        if (!(s_handle.suspend_lock_mask & (0x1 << lock))) {
            return -1;
        }

        s_handle.suspend_lock_mask &= ~(0x1 << lock);
        return 0;
    } else {
        return -1;
    }
}

int LvpPmuSuspendLock(int lock)
{
    if (!(s_handle.suspend_lock_mask & (0x1 << (lock - 1)))) {
        return -1;
    }

    if (lock <= 32) {
        s_handle.suspend_lock |= (0x1 << (lock - 1));
        return 0;
    } else if (lock != 0) {
        return -1;
    } else {
        s_handle.suspend_lock = 0;
        return 0;
    }

    return -1;
}

int LvpPmuSuspendUnlock(int lock)
{

    if (lock <= 32) {
        s_handle.suspend_lock &= ~(0x1 << (lock - 1));
        return 0;
    } else if (lock != 0) {
        return -1;
    } else {
        s_handle.suspend_lock = 0;
        return 0;
    }

    return -1;
}

int LvpPmuSuspendIsLocked(void)
{
    if (s_handle.suspend_lock)
        return 1;
    else
        return 0;
}


int LvpPmuSuspend(int type)
{
    unsigned int irq_state = uni_lock_irq_save();

    if (s_handle.suspend_lock) {
        uni_unlock_irq_restore(irq_state);
        return -1;
    }
    for (int i = 0; i < s_handle.s_suspend_info_num; i++) {
        s_handle.s_suspend_info_buffer[i].suspend_callback(s_handle.s_suspend_info_buffer[i].priv);
    }
    uni_unlock_irq_restore(irq_state);

    LvpAudioInSuspend();
    uni_npu_exit();

    struct uni_pmu_wakeup_addr wakeup_addr = {
        .wakeup_from = UNI_PMU_WAKEUP_FROM_SRAM,
        .wakeup_address = CONFIG_STAGE2_IRAM_BASE + 0x100,
    };

    int data = type; //UNI_PMU_WAKEUP_AUDIO_IN | UNI_PMU_WAKEUP_GPIO;
    uni_pmu_ctrl_set(UNI_PMU_CMD_WAKEUP_MODE, &data);
    uni_pmu_ctrl_set(UNI_PMU_CMD_WAKEUP_ADDR, &wakeup_addr);

    //        printf("mcu gate          :0xa0300018 = 0x%x\n", readl(0xa0300018));
    //        printf("mcu div           :0xa0300080 = 0x%x, 0xa0300084 = 0x%x\n", readl(0xa0300080), readl(0xa0300084));
    //        printf("mcu source select :0xa0300088 = 0x%x\n", readl(0xa0300088));
    //
    //        printf("pmu gate          :0xa0010018 = 0x%x\n", readl(0xa0010018));
    //        printf("pmu div           :0xa0010080 = 0x%x, 0xa0010084 = 0x%x, 0xa0010088 = 0x%x\n", readl(0xa0010080), readl(0xa0010084), readl(0xa0010088));
    //        printf("pmu source select :0xa0010088 = 0x%x\n", readl(0xa001008C));

    printf("set mcu sleep\n");
    uni_audio_in_set_interrupt_enable(AUDIO_IN_IRQ_FFTVAD_START, 1);

    uni_pmu_ctrl_enable();
    return 0;
}

int LvpPmuPowerOff(void)
{
    LvpAudioInSuspend();
    uni_npu_exit();

    printf(LOG_TAG"Start sleeping\n");
    struct uni_pmu_wakeup_addr wakeup_addr = {
        .wakeup_from = UNI_PMU_WAKEUP_FROM_SRAM,
        .wakeup_address = CONFIG_STAGE2_IRAM_BASE + 0x100,
    };

    int data = UNI_PMU_WAKEUP_AUDIO_IN | UNI_PMU_WAKEUP_GPIO;
    uni_pmu_ctrl_set(UNI_PMU_CMD_WAKEUP_MODE, &data);
    uni_pmu_ctrl_set(UNI_PMU_CMD_WAKEUP_ADDR, &wakeup_addr);

    //        printf("mcu gate          :0xa0300018 = 0x%x\n", readl(0xa0300018));
    //        printf("mcu div           :0xa0300080 = 0x%x, 0xa0300084 = 0x%x\n", readl(0xa0300080), readl(0xa0300084));
    //        printf("mcu source select :0xa0300088 = 0x%x\n", readl(0xa0300088));
    //
    //        printf("pmu gate          :0xa0010018 = 0x%x\n", readl(0xa0010018));
    //        printf("pmu div           :0xa0010080 = 0x%x, 0xa0010084 = 0x%x, 0xa0010088 = 0x%x\n", readl(0xa0010080), readl(0xa0010084), readl(0xa0010088));
    //        printf("pmu source select :0xa0010088 = 0x%x\n", readl(0xa001008C));

    printf("set mcu sleep\n");
    uni_audio_in_set_interrupt_enable(AUDIO_IN_IRQ_FFTVAD_START, 1);

    uni_pmu_ctrl_enable();
    return 0;
}

int LvpPmuResume(void)
{
    return 0;
}



