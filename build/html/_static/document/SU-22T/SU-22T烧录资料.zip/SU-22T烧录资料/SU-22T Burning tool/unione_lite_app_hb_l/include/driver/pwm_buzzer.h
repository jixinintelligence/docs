/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : pwm_buzzer.h
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/
#ifndef _PWM_BUZZER_H
#define _PWM_BUZZER_H

/**
 * @brief 蜂鸣器播放事件
 */
typedef enum {
  EVENT_BUZZER_FINISH,  ///< 播放结束
  EVENT_BUZZER_ERR,     ///< 播放异常
} BUZZER_EVENT;

/**
 * @brief 蜂鸣器事件回调函数
 *
 * @param buzzer_event_id 蜂鸣器播放事件
 * @param data 私有参数
 *
 * @retval 无
 */
typedef void (*UserBuzzerEventCallback)(int buzzer_event_id, void *data);

/**
 * @brief 音调
 */
typedef struct {
  unsigned int hz;          ///< 频率
  unsigned int timeout_ms;  ///< 播放时长
}buzzer_tone_t;

/**
 * @brief 初始化蜂鸣器
 *
 * @param pin 蜂鸣器驱动pin脚
 * @param cb 蜂鸣器事件回调函数
 *
 * @retval 0 成功
 * @retval -1 失败
 */
int user_buzzer_init(unsigned int pin, UserBuzzerEventCallback cb);

/**
 * @brief 关闭蜂鸣器
 *
 * @retval 0 成功
 * @retval -1 失败
 */
int user_buzzer_final(void);

/**
 * @brief 开始蜂鸣器播放
 *
 * @param tone_list 待播报的音调集
 * @param len 音调集的总数目
 *
 * @retval 0 成功
 * @retval -1 失败
 */
int user_buzzer_play(buzzer_tone_t *tone_list, int len);

/**
 * @brief 停止蜂鸣器播放
 *
 * @retval 0 成功
 * @retval -1 失败
 */
int user_buzzer_stop(void);
#endif
