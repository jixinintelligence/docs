/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : oem.h
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/
#ifndef __OEM_H__
#define __OEM_H__

#include <common.h>

#define OEM_SIZE (64*1024)

int oem_get_hardware_version(uint32_t *version);
int oem_get_software_version(uint32_t *version);
int oem_get_software_crc32(uint32_t *crc32);
int oem_get_vender_id(uint16_t *vender_id);
int oem_get_product_id(uint16_t *product_id);
int oem_get_sn(uint8_t *sn);
int oem_init(uint32_t start);

#endif
