/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : lvp_system_init.c
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/
#include <autoconf.h>
#include <stdio.h>
#include <types.h>
#include <base_addr.h>
#include <board_config.h>

#include <driver/uni_uart.h>
#include <driver/uni_timer.h>
#include <driver/uni_flash.h>
#include <driver/uni_irq.h>
#include <driver/uni_i2c.h>
#include <driver/uni_gpio.h>
#include <driver/uni_delay.h>
#include <driver/uni_watchdog.h>
#include <driver/uni_dma_ahb.h>
#include <driver/uni_delay.h>
#include <driver/uni_gpio.h>
#include <driver/uni_audio_in.h>
#include <driver/uni_flash.h>
#include <driver/uni_timer.h>
#include <driver/uni_pmu_ctrl.h>
#include <driver/misc.h>
#include <driver/spi.h>
#include <driver/device.h>
#include <driver/uni_clock.h>

#include <lvp_board.h>
#include <lvp_param.h>

#include <lvp_pmu.h>
#include <board_misc_config.h>
#include <lvp_system_init.h>
#include "uni_auto_control.h"
#include "fakelibc.h"

#define LOG_TAG "[LVP]"

#define HEAP_SIZE   (1024 * 64)
static char g_heap_buf[HEAP_SIZE] __attribute__ ((aligned(4))) = {0};


__attribute__((unused)) static int _GetCpuFreq(void)
{
  return uni_clock_get_module_frequence(CLOCK_MODULE_SCPU);
}

__attribute__((unused)) static int _GetSramFreq(void)
{
  return uni_clock_get_module_frequence(CLOCK_MODULE_SRAM);
}

__attribute__((unused)) static int _GetNpuFreq(void)
{
  return uni_clock_get_module_frequence(CLOCK_MODULE_NPU);
}
__attribute__((unused)) static int _GetFlashFreq(void)
{
  return uni_clock_get_module_frequence(CLOCK_MODULE_FLASH_SPI);
}

__attribute__((unused)) static int _GetLdoTrim(void)
{
  UNI_PMU_TRIM_CFG cfg;
  uni_pmu_ctrl_get(UNI_PMU_CMD_WORK_LDO_TRIM, &cfg);
  return cfg.bits.trim_val;
}

void LvpSystemInit(void)
{
  //uni_watchdog_init(2000, 2000, NULL);
  uni_cache_init();
  uni_dma_init();
#ifdef CONFIG_MCU_ENABLE_PRINTF
#ifdef DEBUG_UART
  uni_console_init(DEBUG_UART, CONFIG_SERIAL_BAUD_RATE);
#else
  uni_console_init(1, CONFIG_SERIAL_BAUD_RATE);
#endif
#endif
  UNI_WAKEUP_SOURCE start_mode = uni_pmu_get_wakeup_source();
  if (start_mode == UNI_WAKEUP_SOURCE_COLD || start_mode == UNI_WAKEUP_SOURCE_WDT) {
    printf(LOG_TAG"Board Model: [%s]\n", CONFIG_BOARD_MODEL);
    printf(LOG_TAG"APP Version: [%s]\n", APP_VERSION);
    printf(LOG_TAG"Build Date : [%s]\n", BUILD_TIME);

    /* Flash Info
    UNI_FLASH_DEV *flash   = uni_spi_flash_probe(CONFIG_SF_DEFAULT_BUS, CONFIG_SF_DEFAULT_CS, CONFIG_SF_DEFAULT_SPEED, CONFIG_SF_DEFAULT_MODE);
    unsigned int flash_id = uni_spi_flash_getinfo(flash, UNI_FLASH_CHIP_ID);
    if (flash_id == 0x00854012 || flash_id == 0x00856013) {
      printf(LOG_TAG"Flash vendor:[%s]\n", "PUYA");
    }
    if (flash_id == 0x001c3812 || flash_id == 0x001c3813) {
      printf(LOG_TAG"Flash vendor:[%s]\n", "ESMT");
    }
    printf(LOG_TAG"Flash type:  [%s]\n",      uni_spi_flash_gettype(flash));
    printf(LOG_TAG"Flash ID:    [%#x]\n",     flash_id);
    printf(LOG_TAG"Flash size:  [%d Byte]\n", uni_spi_flash_getinfo(flash, UNI_FLASH_CHIP_SIZE));
    */

#ifdef CONFIG_MCU_ENABLE_DYNAMICALLY_ADJUSTMENT_CPU_FREQUENCY
    printf(LOG_TAG"CPU   Freq:  [%d Hz][Auto]\n", _GetCpuFreq());
#else
    printf(LOG_TAG"CPU   Freq:  [%d Hz][fix]\n", _GetCpuFreq());
#endif
    printf(LOG_TAG"SRAM  Freq:  [%d Hz]\n",      _GetSramFreq());
    printf(LOG_TAG"NPU   Freq:  [%d Hz]\n",      _GetNpuFreq());
    printf(LOG_TAG"FLASH Freq:  [%d Hz]\n",      _GetFlashFreq());
    printf(LOG_TAG"Ldo   Trim:  [%d]\n",          _GetLdoTrim());

#ifdef CONFIG_MCU_ENABLE_STACK_MONITORING
    LvpStackInit();
#endif
    uni_gpio_init();
#ifdef CONFIG_UNI_AUTO_GPIO
    user_gpio_init();
#else
    BoardInit();
#endif
  }
  uni_timer_init();
  uni_irq_init();
  uni_heap_init(g_heap_buf, HEAP_SIZE);

  LvpPmuInit();
}

void LvpSystemDone(void)
{

}

DRAM0_STAGE2_SRAM_ATTR int LvpStackInit(void)
{
  extern int _start_stack_section_ , _end_stack_section_;
  memset(&_start_stack_section_, 0x5A, (unsigned int)&_end_stack_section_ - (unsigned int)&_start_stack_section_);
  printf (LOG_TAG" The Stack Scope:[%#x - %#x], Stack Size:%x\n", CONFIG_STAGE2_STACK, &_start_stack_section_, CONFIG_STAGE2_STACK - (int)&_start_stack_section_);

  return 0;
}

DRAM0_STAGE2_SRAM_ATTR int LvpStackSecurityMonitoring(void)
{
  extern int _start_stack_section_;
  unsigned int *start_stack = (unsigned int*)&_start_stack_section_;
  for (int i = 0; i < 50; i++) {
    if (start_stack[i] != 0x5A5A5A5A) {
      printf (LOG_TAG"Error, The Stack May Used Up, Top[%#x],[Addr:%#x, Value:%#x]\n", &_start_stack_section_, &start_stack[i], start_stack[i]);
    }
  }

  return 0;
}

