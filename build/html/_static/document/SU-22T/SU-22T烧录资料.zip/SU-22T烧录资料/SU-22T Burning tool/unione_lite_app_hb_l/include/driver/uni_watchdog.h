/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : uni_watchdog.h
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/

#ifndef __UNI_WATCHDOG_H__
#define __UNI_WATCHDOG_H__
/** @addtogroup WATCHDOG
 *  @brief 看门狗实际可配时间(ms): 1048 2097 4194 8388 16772，接口会自动配置为不小于入参的最近时间。
@{*/

#include <common.h>
#include <driver/uni_irq.h>

/**
 * @brief 看门狗初始化
 *
 * @param reset_timeout_ms 看门狗复位芯片超时时间（连续两次超时会复位芯片）
 * @param level_timeout_ms 看门狗产生超时时间（小于复位超时时间且设置了回调函数，将不会复位芯片）
 * @param irq_handler 中断服务回调函数
 */
void uni_watchdog_init(uint16_t reset_timeout_ms,
		uint16_t level_timeout_ms, irq_handler_t irq_handler);

/**
 * @brief 看门狗喂狗
 */
void uni_watchdog_ping(void);

/**
 * @brief 重启
 *
 * @return int 复位函数，不会返回
 */
int uni_reboot(void);

#endif
