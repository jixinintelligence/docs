/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : lvp_app_core.h
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/
#ifndef __LVP_APP_EVENT_H__
#define __LVP_APP_EVENT_H__

typedef struct {
    unsigned int event_id;
    unsigned int ctx_index;
    void         *attach;
} APP_EVENT;

// Private Event ID [1~99] for APP
#define LVP_WAKE_UP_EVENT_ID          (90)
#define AUDIO_IN_RECORD_DONE_EVENT_ID (91)

// Pubilic Event ID [100~200] for Unione event
#define UNI_KWS_WAKEUP_EVENT_ID       (100)
#define UNI_KWS_CMD_EVENT_ID          (101)
#define UNI_KWS_SLEEP_EVENT_ID        (102)
#define UNI_REPLAY_END_EVENT_ID       (200)

//=============================================================================//
typedef struct {
  char        word[64];
  const char  *action;
  float       score;
  const char  *replay;
}uni_kws_result_t;

//=============================================================================//
typedef enum {
    PBT_UNDEFINE        = 0x0,
    PBT_OTHER           = 0x1,
    PBT_VOICE_PLAY      = 0x2,
    PBT_UART_ASYNC_SEND = 0x4,
    PBT_LED_CONTRL      = 0x8,
    PBT_ENABLE_UART_SEND_WAV = 0xa,
} APP_BEHAVIOR_TYPE;

//=============================================================================//
typedef enum {
    PST_SWITCH_VPA_MODE = 1,
    PST_NEW_VOICE_PLAY_TASK = 2,
} APP_STATUS_TYPE;

typedef struct {
    enum {
        APP_STATUS_VPA_ACTIVE,
        APP_STATUS_VPA_TALKING,
        APP_STATUS_VPA_BYPASS,
        APP_STATUS_VPA_IDLE
    } vpa_mode;
    unsigned char new_voice_play_task;
} APP_STATUS;


int LvpInitializeAppEvent(void);
int LvpTriggerAppEvent(APP_EVENT *app_event);
int LvpAppEventTick(void);

#endif /* __LVP_APP_EVENT_H__ */
