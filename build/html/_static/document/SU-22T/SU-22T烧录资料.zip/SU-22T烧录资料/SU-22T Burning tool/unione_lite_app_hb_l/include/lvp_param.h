/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : lvp_param.h
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/

#ifndef __LVP_PARAM_H__
#define __LVP_PARAM_H__

#include <driver/uni_audio_in.h>
#include <driver/uni_padmux.h>

//=================================================================================================
// Audio In Board Ctrl

enum {
    TRACK_MONO,
    TRACK_STEREO,
};

typedef struct {
    unsigned pcm0    :1;
    unsigned pcm1    :1;
    unsigned logfbank:1;
    unsigned i2s     :1;
    unsigned reserve :28;
} LVP_AUDIO_IN_CHANNEL;

typedef struct {
    unsigned pga_gain               :6;
    unsigned audio_in_gain          :4;
    unsigned dc_enable              :1;
    unsigned pcm_output_track       :1;
    unsigned reserve                :20;
    UNI_AUDIO_IN_EVAD            evad;
    UNI_AUDIO_IN_EVAD_THRESHOLD  evad_threshold;
} LVP_AUDIO_IN_SOURCE_CONFIG;

typedef struct {
    UNI_AUDIO_IN_SOURCE          input_source;
    LVP_AUDIO_IN_SOURCE_CONFIG  input_source_config[3];

    LVP_AUDIO_IN_CHANNEL        output_channel;
    UNI_AUDIO_IN_INPUT_SADC      sadc;
    UNI_AUDIO_IN_INPUT_PDM       pdm;
    UNI_AUDIO_IN_INPUT_I2S       i2s_in;

    UNI_AUDIO_IN_OUTPUT_PCM      pcm0;
    UNI_AUDIO_IN_OUTPUT_PCM      pcm1;
    UNI_AUDIO_IN_OUTPUT_LOGFBANK logfbank;
    UNI_AUDIO_IN_OUTPUT_I2S      i2s_out; // note: i2s_out dont have tdm mode
    UNI_AUDIO_IN_OUTPUT_SPECTRUM spectrum;

} LVP_AUDIO_IN_PARAM_CTRL;

//=================================================================================================
// Hw Pin Config List

typedef struct {
    unsigned int    count;
    UNI_PIN_CONFIG  *pin_config_table;
} LVP_PIN_CONFIG_TABLE;

//=================================================================================================
// Key Words Param List

typedef struct {
    char kws_words[40];          // Key words
    char labels[14];             // The label of key words
    int  label_length;           // The length of key label
    int  threshold;           // The threshold of kws
    int  kws_value;              // The event id for mcu
    int  major;                  // 1 -->> Major Kws, 0 -->> Shor instruction
} LVP_KWS_PARAM;

typedef struct {
    unsigned int    count;
    LVP_KWS_PARAM  *kws_param_list;
} LVP_KWS_PARAM_LIST;

typedef struct {
    unsigned char *lm;
    unsigned int   lm_size;
    unsigned char *lst;
    unsigned int   lst_size;
} LANGUAGE_MODEL_PARAM;
//=================================================================================================

enum {
    ENV_LOW_NOISE,
    ENV_MID_NOISE,
    ENV_HIGH_NOISE,
};

//=================================================================================================

#define MAX_STR_STASH 30

typedef struct {
    int  id;
    char kws_words[20];          // Key words
    char labels[14];             // The label of key words
    int  label_length;           // The length of key label
    int  prev;
    int  next;
    int  ctc_enable;            //0: only beamSearch; 1: ctc
    int  threshold;
} LVP_KWS_SEGMENTATION_PARAM;

enum {
    DELAY = -1,
    ROOT = 0,
    LEAF = 0,
    COMMON_MASK_0  =  1 <<  0 ,
    COMMON_MASK_1  =  1 <<  1 ,
    COMMON_MASK_2  =  1 <<  2 ,
    COMMON_MASK_3  =  1 <<  3 ,
    COMMON_MASK_4  =  1 <<  4 ,
    COMMON_MASK_5  =  1 <<  5 ,
    COMMON_MASK_6  =  1 <<  6 ,
    COMMON_MASK_7  =  1 <<  7 ,
    COMMON_MASK_8  =  1 <<  8 ,
    COMMON_MASK_9  =  1 <<  9 ,
    COMMON_MASK_10  =  1 <<  10 ,
    COMMON_MASK_11  =  1 <<  11 ,
    COMMON_MASK_12  =  1 <<  12 ,
    COMMON_MASK_13  =  1 <<  13 ,
    COMMON_MASK_14  =  1 <<  14 ,
    COMMON_MASK_15  =  1 <<  15 ,
    COMMON_MASK_16  =  1 <<  16 ,
    COMMON_MASK_17  =  1 <<  17 ,
    COMMON_MASK_18  =  1 <<  18 ,
    COMMON_MASK_19  =  1 <<  19 ,
    COMMON_MASK_20  =  1 <<  20 ,
    COMMON_MASK_21  =  1 <<  21 ,
    COMMON_MASK_22  =  1 <<  22 ,
    COMMON_MASK_23  =  1 <<  23 ,
    COMMON_MASK_24  =  1 <<  24 ,
    COMMON_MASK_25  =  1 <<  25 ,
    COMMON_MASK_26  =  1 <<  26 ,
    COMMON_MASK_27  =  1 <<  27 ,
    COMMON_MASK_28  =  1 <<  28 ,
    COMMON_MASK_29  =  1 <<  29 ,
    COMMON_MASK_30  =  1 <<  30 ,
    COMMON_MASK_31  =  1 <<  31 ,
};
#endif /* __LVP_PARAM_H__*/
