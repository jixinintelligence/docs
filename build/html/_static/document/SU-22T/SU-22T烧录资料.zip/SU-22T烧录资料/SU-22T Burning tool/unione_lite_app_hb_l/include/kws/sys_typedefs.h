/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : sys_typedefs.h
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/
/**
 * @file sys_typedefs.h
 * @brief Define value types, constants and macros
 * @details
 * @authors Li Peng
 * @copyright 2014-2020 Unisound AI Technology Co., Ltd. All rights reserved.
 */

#ifndef PLAT_SYS_TYPEDEFS_H_
#define PLAT_SYS_TYPEDEFS_H_

#include <float.h>

// Define fixed-width integers
#ifdef _WIN32
#if _MSC_VER == 1200  // vc6
typedef __int8 int8_t;
typedef __int16 int16_t;
typedef __int32 int32_t;
typedef __int64 int64_t;
typedef unsigned __int8 uint8_t;
typedef unsigned __int16 uint16_t;
typedef unsigned __int32 uint32_t;
typedef unsigned __int64 uint64_t;
#else  // _MSC_VER == 1200
#include <stdint.h>
#endif  // _MSC_VER == 1200
#else   // _WIN32
#include <stdint.h>
#endif  // _WIN32

// Define constants
#define LZERO (-1000000000)  //  ~log(0)

// Define macros for convenience
#ifndef NULL
#define NULL 0
#endif  // NULL

#ifndef bool
#define bool int
#define false 0
#define true 1
#endif  // bool

#endif  // PLAT_SYS_TYPEDEFS_H_
