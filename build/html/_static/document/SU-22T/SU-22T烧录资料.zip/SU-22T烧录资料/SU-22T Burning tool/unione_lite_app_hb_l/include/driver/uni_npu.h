#ifndef __UNI_NPU_H__
#define __UNI_NPU_H__

#include "autoconf.h"

/**
 * @brief 初始化npu
 *
 *
 * @return npu 初始化成功与否
 * @retval 0 正常
 * @retval -1 失败
 */
int uni_npu_init(void);

/**
 * @brief 关闭npu
 *
 *
 * @return npu 关闭成功与否
 * @retval 0 正常
 * @retval -1 失败
 */
int uni_npu_exit(void);

#endif
