/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : uni_padmux.h
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/
#ifndef __UNI_PADMUX_H__
#define __UNI_PADMUX_H__
/** @addtogroup PINMUX
@{*/
/**
 * @brief 管脚复用配置
 */
typedef struct pin_config {
	unsigned char pin_id;   ///< pin 脚号
	unsigned char function; ///< 复用功能
} UNI_PIN_CONFIG;

/**
 * @brief 配置管脚复用功能
 *
 * @param pad_id pin 脚号
 * @param function 复用功能
 * @return int 是否成功
 * @retval 0 成功
 * @retval -1 失败
 */
int padmux_set(int pad_id, int function);

/**
 * @brief 获取管脚复用功能
 *
 * @param pad_id pin 脚号
 * @return int 是否成功
 * @retval 0 成功
 * @retval -1 失败
 */
int padmux_get(int pad_id);

/**
 * @brief 管脚复用功能检查
 *
 * @param pad_id pin 脚号
 * @param function 复用功能
 * @return int 检测是否正常
 * @retval 0 正常
 * @retval -1 异常
 */
int padmux_check(int pad_id, int function);

/**
 * @brief 管脚复用初始化
 *
 * @param pin_table 管脚复用表
 * @param size 管脚复用表大小
 * @return int 是否成功
 * @retval 0 正常
 * @retval -1 异常
 */
int padmux_init(const UNI_PIN_CONFIG *pin_table, int size);

#endif
