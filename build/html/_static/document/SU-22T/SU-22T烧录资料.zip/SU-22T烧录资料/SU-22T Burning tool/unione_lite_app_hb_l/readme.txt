v1.0.11 / v1.0.11_1mb
1.feature:
  1.1 当12、13pin被设置为功能输出时，默认关闭log输出
2. bugfix:
3. perf:
4. requirement:

v1.0.10_1mb
1.feature:
2. bugfix:
 2.1 修复设置默认开机音乐时没有声音的问题
3. perf:
4. requirement:

v1.0.9_1mb
1.feature:
 1.1 修改原有资源映射逻辑，L Pro现在支持自定义tts语音应答了
 1.2 更新模型为7.3.12
2. bugfix:
3. perf:
4. requirement:

v1.0.9
1.feature:
 1.1 支持内部flash读和写，提供使用demo
2. bugfix:
3. perf:
4. requirement:

v1.0.8
1. feature:
 1.1 外挂flash不再限制，512KB~32MB都可加载上，但不再支持列表中的型号，需要使用者确保测试充分
2. bugfix:
 2.1 修复被动播报会crash的问题
3. perf:
4. requirement:

v1.0.7
1. feature:
 1.1 支持MP3音频播放,并且默认播放模式设为MP3
 1.2 添加user_play音频播放相关接口
2. bugfix:
3. perf:
4. requirement:

v1.0.6
1. feature:
2. bugfix:
3. perf:
4. requirement:
  4.1 更新烧录工具

v1.0.5
1. feature:
  1.1 支持从外挂norflash读取音频数据进行播报[支持的norflash型号为：GD25Q32E]
2. bugfix:
3. perf:
4. requirement:
  4.1 蜂鸣器默认使用gpio_09

v1.0.4
1. feature:
  1.1 支持watchdog
  1.2 编译支持【录音模式】（./build record）
2. bugfix:
3. perf:
4. requirement:

v1.0.0
1. feature:
  1.1 支持udp平台构建请求
  1.2 更新kws v7.3.0 #972
2. bugfix:
3. perf:
4. requirement:
