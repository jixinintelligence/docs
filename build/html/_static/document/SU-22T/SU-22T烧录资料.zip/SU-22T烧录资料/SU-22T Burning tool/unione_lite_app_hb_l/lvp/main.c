/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : main.c
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/

#include <autoconf.h>
#include <stdio.h>

#include <lvp_attr.h>
#include <lvp_system_init.h>
#include "lvp_mode.h"
#include "app_core/lvp_app_core.h"


DRAM0_STAGE2_SRAM_ATTR int main(int argc, char **argv)
{
    LvpSystemInit();

#if defined(CONFIG_LVP_INIT_WORKMODE_KWS)
    LvpInitMode(LVP_MODE_KWS);
#else
    LvpInitMode(LVP_MODE_IDLE);
#endif

    LvpInitializeAppEvent();

    while(LvpModeTick()) {
#ifdef CONFIG_MCU_ENABLE_STACK_MONITORING
        LvpStackSecurityMonitoring();
#endif
        LvpAppEventTick();

        continue;
    }
    LvpSystemDone();
}

