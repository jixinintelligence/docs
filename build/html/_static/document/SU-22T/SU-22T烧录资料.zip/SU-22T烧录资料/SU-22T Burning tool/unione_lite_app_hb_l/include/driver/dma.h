/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : dma.h
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/

#ifndef __DMA_H__
#define __DMA_H__

#include <types.h>

/*
 * enum dma_direction - dma transfer direction indicator
 * @DMA_MEM_TO_MEM: Memcpy mode
 * @DMA_MEM_TO_DEV: From Memory to Device
 * @DMA_DEV_TO_MEM: From Device to Memory
 * @DMA_DEV_TO_DEV: From Device to Device
 */
enum dma_direction {
	DMA_MEM_TO_MEM,
	DMA_MEM_TO_DEV,
	DMA_DEV_TO_MEM,
	DMA_DEV_TO_DEV,
};

#define BIT(n)                  (1 << n)

#define DMA_SUPPORTS_MEM_TO_MEM BIT(0)
#define DMA_SUPPORTS_MEM_TO_DEV BIT(1)
#define DMA_SUPPORTS_DEV_TO_MEM BIT(2)
#define DMA_SUPPORTS_DEV_TO_DEV BIT(3)
#define DMA_SUPPORTS_SPI        BIT(8)


struct dma_ops {
	int   (*transfer)(void *dst, void *src, size_t len, int direction);
	void* (*dma_addr_get)(void *addr, uint32_t flag);
};

extern struct dma_ops *dma_ops_get(void);
extern int    dma_memcpy(void *dst, void *src, size_t len);
extern int    dma_xfer(void *dest,void *src, size_t len, int direction);



#endif

