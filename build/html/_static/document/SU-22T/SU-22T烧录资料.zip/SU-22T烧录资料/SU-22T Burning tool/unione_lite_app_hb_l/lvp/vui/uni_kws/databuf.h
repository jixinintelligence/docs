/**************************************************************************
 * Copyright (C) 2017-2017  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : databuf.h
 * Author      : wufangfang@unisound.com
 * Date        : 2019.08.08
 *
 **************************************************************************/

#ifndef _UTILS_INC_DATABUF_H_
#define _UTILS_INC_DATABUF_H_

#ifdef __cplusplus
extern "C" {
#endif

typedef void* DataBufHandle;

/**
 * Usage:   Creat data buffer
 * Params:  size:   size of ring buffer
 * Return:  Handle of data buffer, NULL means failed
 */
DataBufHandle DataBufferCreate(int size);

/**
 * Usage:   Creat data buffer with external buffer, will not alloc buffer again
 * Params:  buf:    external buffer
 *          size:   size of external buffer
 * Return:  Handle of data buffer, NULL means failed
 */
DataBufHandle DataBufferCreateWithBuffer(char *buf, int size);

/**
 * Usage:   Destroy data buffer
 * Params:  handle:   Handle of data buffer
 * Return:  0 means successful, otner means failed
 */
int DataBufferDestroy(DataBufHandle handle);

/**
 * Usage:   Peek read data, will not clear buffer, can read it again
 * Params:  handle:   Handle of data buffer
 *          dst:      buffer for save data
 *          readlen:  size need to read
 * Return:  Length of readed, <=0 means failed
 */
int DataBufferPeek(char *dst, int readlen, DataBufHandle handle);

/**
 * Usage:   Clear all data buffer
 * Params:  handle:   Handle of data buffer
 * Return:  0 means successful, otner means failed
 */
int DataBufferClear(DataBufHandle handle);

/**
 * Usage:   Get free size of data buffer can be writed
 * Params:  handle:   Handle of data buffer
 * Return:  free size of data buffer, <=0 means failed
 */
int DataBufferGetFreeSize(DataBufHandle handle);

/**
 * Usage:   Get data size of data buffer can be read
 * Params:  handle:   Handle of data buffer
 * Return:  data size of data buffer, <=0 means failed
 */
int DataBufferGetDataSize(DataBufHandle handle);

/**
 * Usage:   Write data to data bufer
 * Params:  handle:   Handle of data buffer
 *          src:      Point to data want to writed
 *          writelen: length of data want to write
 * Return:  data size writed, <=0 means failed
 */
int DataBufferWrite(DataBufHandle handle, const char *src, int writelen);

/**
 * Usage:   Read data from data bufer
 * Params:  handle:   Handle of data buffer
 *          dst:      buffer for save data
 *          readlen:  length of data want to read
 * Return:  data size read, <=0 means failed
 */
int DataBufferRead(char *dst, int readlen, DataBufHandle handle);

/**
 * Usage:   Skip some data in data buffer
 * Params:  handle:   Handle of data buffer
 *          readlen:  length of data want to skip
 * Return:  data size skipped, <=0 means failed
 */
int DataBufferSkip(int readlen, DataBufHandle handle);

/**
 * Usage:   Write data to data buffer, overwrit existing data
 * Params:  handle:   Handle of data buffer
 *          src:      Point to data want to writed
 *          writelen: length of data want to write
 * Return:  data size writed, <=0 means failed
 */
int DataBufferWriteForcely(DataBufHandle handle, const char *src,
                                  int writelen);

/**
 * Usage:   Copy data from a data buffer to another
 * Params:  dst:      Handle of data buffer that destination
 *          src:      Handle of data buffer that source
 *          copylen:  length of data want to copy
 *          forcely:  overwrit or not
 * Return:  data size copied, <=0 means failed
 */
int DataBufferCopy(DataBufHandle dst, DataBufHandle src, int copylen,
                        int forcely);

/**
 * Usage:   Move data from a data buffer to another
 * Params:  dst:      Handle of data buffer that destination
 *          src:      Handle of data buffer that source
 *          copylen:  length of data want to copy
 *          forcely:  overwrit or not
 * Return:  data size movied, <=0 means failed
 */
int DataBufferMove(DataBufHandle dst, DataBufHandle src, int movelen,
                        int forcely);

/**
 * Usage:   Copy all data from a data buffer to another
 * Params:  dst:      Handle of data buffer that destination
 *          src:      Handle of data buffer that source
 *          forcely:  overwrit or not
 * Return:  data size movied, <=0 means failed
 */
int DataBufferCopyAll(DataBufHandle dst, DataBufHandle src, int forcely);

/**
 * Usage:   Move all data from a data buffer to another
 * Params:  dst:      Handle of data buffer that destination
 *          src:      Handle of data buffer that source
 *          forcely:  overwrit or not
 * Return:  data size movied, <=0 means failed
 */
int DataBufferMoveAll(DataBufHandle dst, DataBufHandle src, int forcely);

#ifdef __cplusplus
}
#endif
#endif
