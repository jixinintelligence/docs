/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : autoconf.h
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/
#ifndef __AUTOCONF_H__
#define __AUTOCONF_H__

//
// Board Options: 
//
#define CONFIG_BOARD_MODEL "us513_demo_v1"

//
// Microphone Type selects:
//
// CONFIG_TYPE_DMIC is not set
#define CONFIG_TYPE_AMIC
#define CONFIG_TYPE_AMIC_TRACK 1

//
// MCU settings
//
#define CONFIG_MCU_ENABLE_PRINTF
#define CONFIG_MCU_MAIN_STACK_SIZE 4
// CONFIG_MCU_ENABLE_STACK_MONITORING is not set
#define CONFIG_MCU_ENABLE_XIP
// CONFIG_MCU_DEFAULT_TEXT_IN_SRAM is not set
#define CONFIG_MCU_DEFAULT_TEXT_IN_FLASH
#define CONFIG_NPU_RUN_IN_FLASH

// CONFIG_SYSTICK_COUNTER is not set
#define CONFIG_UNI_COUNTER


//
// NPU settings
//
// should larger than kws_data_content (from labs moudle.h)
#define CONFIG_NPU_SRAM_SIZE_KB 20

//
// LVP Workmode settings
//
#define CONFIG_LVP_INIT_WORKMODE_KWS
#define CONFIG_LVP_HAS_KWS_MODE

//
// I/O Buffer Settings
//
#define CONFIG_MIC_CHANNEL_NUM 1
#define CONFIG_LOGFBANK_CHANNEL_NUM 1

//
// Frame settings:
//
// CONFIG_PCM_SAMPLE_RATE_8K is not set
#define CONFIG_PCM_SAMPLE_RATE_16K
// CONFIG_PCM_SAMPLE_RATE_48K is not set
#define CONFIG_PCM_FRAME_LENGTH_10MS
// CONFIG_PCM_FRAME_LENGTH_16MS is not set

//
// Context settings:
//
#define CONFIG_LVP_PCM_FRAME_NUM_PER_CONTEXT 6
#define CONFIG_LVP_CONTEXT_GAP 1

//
// Buffer settings:
//
//
#define CONFIG_LVP_BUFFER_HAS_MIC
// CONFIG_LVP_BUFFER_HAS_REF is not set
//#define CONFIG_LVP_BUFFER_HAS_FFT
//#define CONFIG_ENABLE_HARDWARE_FFT
#define CONFIG_LVP_BUFFER_HAS_LOGFBANK
// CONFIG_LVP_BUFFER_HAS_OUTPUT is not set

#ifdef CONFIG_UNI_UART_RECORD
#define CONFIG_LVP_PCM_FRAME_NUM_PER_CHANNEL 36
#else
#define CONFIG_LVP_PCM_FRAME_NUM_PER_CHANNEL 12
#endif
#define CONFIG_LVP_LOGFBANK_FRAME_NUM_PER_CHANNEL 48
#define CONFIG_LVP_FFT_FRAME_NUM_PER_CHANNEL 24
#define CONFIG_LVP_CONTEXT_NUM 8

//
// Audio out buffer settings:
//
#define CONFIG_AUDIO_OUT_BUFFER_SIZE_KB 4

//
// VAD settings:
//
#define CONFIG_LVP_FFT_VAD_ENABLE
#define CONFIG_LVP_VAD_FALLBACK_CONTEXT 7

//
// 
//
#define CONFIG_LVP_STANDBY_ENABLE
// CONFIG_LVP_DISABLE_XIP_WHILE_CODE_RUN_AT_SRAM is not set

//
// LVP Application Settings
//
// CONFIG_LVP_APP_NONE is not set
#define CONFIG_UNI_APP_IVM

//
// Application Settings
//
#define CONFIG_UNI_AUTO_GPIO

//
// Common Function Settings
//
#define CONFIG_LVP_HAS_VOICE_PLAYER

//#define CONFIG_HW_EXT_FLASH

#define ArptPrint(...)     printf_( __VA_ARGS__ )


#endif
