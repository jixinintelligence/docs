/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : lvp_attr.h
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/

#ifndef __LVP_ATTR_H__
#define __LVP_ATTR_H__

//=================================================================================================

#define ALIGNED_ATTR(x)         __attribute__((aligned(x)))

#define DRAM0_STAGE2_SRAM_ATTR  __attribute__((section(".sram_text")))

#define XIP_RODATA_ATTR         __attribute__((section(".xip.rodata*")))

#define DRAM0_NPU_ATTR          __attribute__((section(".npu_section")))
#define DRAM0_NPU_CMD_ATTR      __attribute__((section(".cmd")))
#define DRAM0_NPU_WEIGHT_ATTR   __attribute__((section(".weight")))

#define DRAM0_NC_NPU_ATTR          __attribute__((section(".nc_npu_section")))
#define DRAM0_NC_NPU_CMD_ATTR      __attribute__((section(".nc_cmd")))
#define DRAM0_NC_NPU_WEIGHT_ATTR   __attribute__((section(".nc_weight")))

#define DRAM0_VP_NPU_ATTR          __attribute__((section(".vp_npu_section")))
#define DRAM0_VP_NPU_CMD_ATTR      __attribute__((section(".vp_cmd")))
#define DRAM0_VP_NPU_WEIGHT_ATTR   __attribute__((section(".vp_weight")))

#define DRAM0_AUDIO_IN_ATTR     __attribute__((section(".audio_in")))

#define NPU_SRAM_ADDR           0x20000000

//=================================================================================================
#endif /* __LVP_ATTR_H__ */
