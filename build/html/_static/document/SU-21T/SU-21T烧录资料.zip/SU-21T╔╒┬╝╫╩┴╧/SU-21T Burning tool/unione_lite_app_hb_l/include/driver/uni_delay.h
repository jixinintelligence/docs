/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : uni_delay.h
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/
#ifndef __UNI_DELAY_H__
#define __UNI_DELAY_H__

/**
 * @brief 延时初始化
 */
void uni_delay_init(void);

/**
 * @brief us 级延时
 *
 * @param us 延时时长(us)
 */
void uni_udelay(unsigned int us);

/**
 * @brief ms 级延时
 *
 * @param ms 延时时长(ms)
 */
void uni_mdelay(unsigned int ms);

/**
 * @brief 定时器初始化
 */
void uni_timer_init(void);

#endif
