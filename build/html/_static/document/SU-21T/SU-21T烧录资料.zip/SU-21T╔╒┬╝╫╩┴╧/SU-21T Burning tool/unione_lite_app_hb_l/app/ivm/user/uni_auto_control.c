/**************************************************************************
 * Copyright (C) 2020-2020  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : uni_auto_control.c
 * Author      : yuanshifeng@unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/
#include "user_gpio.h"
#include "lvp_mp3_player.h"
#include "printf.h"

#define LOG_TAG "[uni_auto_ctrl]"

static void _user_gpio_set_pinmux(void) {
  user_pin_set_func(USER_PIN_NUM_1, USER_PIN_FUNC_GPIO_PWM);
  user_pin_set_func(USER_PIN_NUM_2, USER_PIN_FUNC_GPIO_PWM);
  user_pin_set_func(USER_PIN_NUM_6, USER_PIN_FUNC_DAC);
  user_pin_set_func(USER_PIN_NUM_7, USER_PIN_FUNC_GPIO_PWM);
  user_pin_set_func(USER_PIN_NUM_8, USER_PIN_FUNC_GPIO_PWM);
  user_pin_set_func(USER_PIN_NUM_9, USER_PIN_FUNC_GPIO_PWM);
  user_pin_set_func(USER_PIN_NUM_11, USER_PIN_FUNC_GPIO_PWM);
  user_pin_set_func(USER_PIN_NUM_12, USER_PIN_FUNC_UART);
  user_pin_set_func(USER_PIN_NUM_13, USER_PIN_FUNC_UART);
  user_pin_set_func(USER_PIN_NUM_18, USER_PIN_FUNC_GPIO_PWM);
  user_pin_set_func(USER_PIN_NUM_19, USER_PIN_FUNC_GPIO_PWM);
  user_pin_set_func(USER_PIN_NUM_20, USER_PIN_FUNC_GPIO_PWM);
}

void user_gpio_resume(void) {
  _user_gpio_set_pinmux();
  user_uart_init(USER_PIN_NUM_12, 9600, 8, 1, 0);
  user_gpio_set_level(USER_PIN_NUM_19, UNI_GPIO_LEVEL_HIGH);
}

void user_gpio_suspend(void) {

}

int user_gpio_init(void) {
  _user_gpio_set_pinmux();

  user_gpio_set_direction(USER_PIN_NUM_1, UNI_GPIO_DIRECTION_OUTPUT);
  user_gpio_set_level(USER_PIN_NUM_1, UNI_GPIO_LEVEL_LOW);
  user_gpio_set_direction(USER_PIN_NUM_2, UNI_GPIO_DIRECTION_OUTPUT);
  user_gpio_set_level(USER_PIN_NUM_2, UNI_GPIO_LEVEL_LOW);
  user_gpio_set_direction(USER_PIN_NUM_7, UNI_GPIO_DIRECTION_OUTPUT);
  user_gpio_set_level(USER_PIN_NUM_7, UNI_GPIO_LEVEL_LOW);
  user_gpio_set_direction(USER_PIN_NUM_8, UNI_GPIO_DIRECTION_OUTPUT);
  user_gpio_set_level(USER_PIN_NUM_8, UNI_GPIO_LEVEL_LOW);
  user_gpio_set_direction(USER_PIN_NUM_9, UNI_GPIO_DIRECTION_OUTPUT);
  user_gpio_set_level(USER_PIN_NUM_9, UNI_GPIO_LEVEL_LOW);
  user_gpio_set_direction(USER_PIN_NUM_11, UNI_GPIO_DIRECTION_OUTPUT);
  user_gpio_set_level(USER_PIN_NUM_11, UNI_GPIO_LEVEL_LOW);
  user_uart_init(USER_PIN_NUM_12, 9600, 8, 1, 0);
  user_gpio_set_direction(USER_PIN_NUM_18, UNI_GPIO_DIRECTION_OUTPUT);
  user_gpio_set_level(USER_PIN_NUM_18, UNI_GPIO_LEVEL_LOW);
  user_gpio_set_direction(USER_PIN_NUM_19, UNI_GPIO_DIRECTION_OUTPUT);
  user_gpio_set_level(USER_PIN_NUM_19, UNI_GPIO_LEVEL_HIGH);
  user_gpio_set_direction(USER_PIN_NUM_20, UNI_GPIO_DIRECTION_OUTPUT);
  user_gpio_set_level(USER_PIN_NUM_20, UNI_GPIO_LEVEL_LOW);

  printf(LOG_TAG " %s success\n", __func__);
  return 0;
}

int user_gpio_handle_kws_event(uni_kws_result_t *kws_result,
                               uint8_t *need_reply) {
  if (kws_result != NULL) {
    printf(LOG_TAG "handle kws result action: %s\n", kws_result->action);

  }

  return 0;
}
