/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : base_addr.h
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/
#ifndef __BASE_ADDR_H__
#define __BASE_ADDR_H__

#define UNI_REG_BASE_PMU              0xA0000000
#define UNI_REG_BASE_GPIO0            0xA0001000
#define UNI_REG_BASE_PWM0             0xA0002000
#define UNI_REG_BASE_RTC              0xA0003000
#define UNI_REG_BASE_OSC              0xA0004000
#define UNI_REG_BASE_HW_I2C           0xA0005000
#define UNI_REG_BASE_PMU_CONFIG       0xA0010000
#define UNI_REG_BASE_UART0            0xA0100000
#define UNI_REG_BASE_UART0_BRC        0xA0100100
#define UNI_REG_BASE_UART1            0xA0200000
#define UNI_REG_BASE_UART1_BRC        0xA0200100
#define UNI_REG_BASE_MCU_CONFIG       0xA0300000
#define UNI_REG_BASE_COUNTER          0xA0400000
#define UNI_REG_BASE_I2C0             0xA0500000
#define UNI_REG_BASE_I2C1             0xA0600000
#define UNI_REG_BASE_WATCHDOG         0xA0700000

#define UNI_REG_BASE_AUDIO_IN         0xA0A00000
#define UNI_REG_BASE_AHB_AUDIO_OUT    0xA0B80000
#define UNI_REG_BASE_SYS_AUDIO_OUT    0xA0B00000

#define UNI_REG_BASE_DMA              0xA1000000
#define UNI_REG_BASE_XIP_CS           0xA0300090
#define UNI_REG_BASE_XIP              0xA2000000
#define UNI_REG_BASE_SPI1             0xA3000000
#define UNI_REG_BASE_SPI1_CS          0xA030008C
#define UNI_REG_BASE_ICACHE           0xB0000000
#define UNI_REG_BASE_MMU              0xB0100000

// pmu config
#define PMU_CFG_MEPG_CLD_RST_NORM       (UNI_REG_BASE_PMU_CONFIG + 0x00)
#define PMU_CFG_MEPG_CLD_RST_1SET       (UNI_REG_BASE_PMU_CONFIG + 0x04)
#define PMU_CFG_MEPG_CLD_RST_1CLR       (UNI_REG_BASE_PMU_CONFIG + 0x08)
#define PMU_CFG_MEPG_HOT_RST_NORM       (UNI_REG_BASE_PMU_CONFIG + 0x0c)
#define PMU_CFG_MEPG_HOT_RST_1SET       (UNI_REG_BASE_PMU_CONFIG + 0x10)
#define PMU_CFG_MEPG_HOT_RST_1CLR       (UNI_REG_BASE_PMU_CONFIG + 0x14)
#define PMU_CFG_MEPG_CLK_INHIBIT_NORM   (UNI_REG_BASE_PMU_CONFIG + 0x18)
#define PMU_CFG_MEPG_CLK_INHIBIT_1SET   (UNI_REG_BASE_PMU_CONFIG + 0x1C)
#define PMU_CFG_MEPG_CLK_INHIBIT_1CLR   (UNI_REG_BASE_PMU_CONFIG + 0x20)
#define PMU_CFG_DTO0_CONFIG             (UNI_REG_BASE_PMU_CONFIG + 0x24)  // Audio
#define PMU_CFG_POWER_ON_RESET_REG0     (UNI_REG_BASE_PMU_CONFIG + 0x2C)
#define PMU_CFG_POWER_ON_RESET_REG1     (UNI_REG_BASE_PMU_CONFIG + 0x30)
#define PMU_CFG_SCPU_CONFIG             (UNI_REG_BASE_PMU_CONFIG + 0x34)
#define PMU_CFG_SCPU_STATUS             (UNI_REG_BASE_PMU_CONFIG + 0x38)
#define PMU_CFG_XTAL_EN                 (UNI_REG_BASE_PMU_CONFIG + 0x4C)
#define PMU_CFG_RST_MCU                 (UNI_REG_BASE_PMU_CONFIG + 0x50)
#define PMU_CFG_MCU_OVERRIDE_ADDR       (UNI_REG_BASE_PMU_CONFIG + 0x54)
#define PMU_CFG_MCU_OVERRIDE_EN         (UNI_REG_BASE_PMU_CONFIG + 0x58)
#define PMU_CFG_RST_PMU                 (UNI_REG_BASE_PMU_CONFIG + 0x60)
#define PMU_CFG_FLASH_START             (UNI_REG_BASE_PMU_CONFIG + 0x64)
#define PMU_CFG_BOOT_MODE               (UNI_REG_BASE_PMU_CONFIG + 0x68)
#define PMU_CFG_CLOCK_DIV_CONFIG0       (UNI_REG_BASE_PMU_CONFIG + 0x80)
#define PMU_CFG_CLOCK_DIV_CONFIG1       (UNI_REG_BASE_PMU_CONFIG + 0x84)
#define PMU_CFG_CLOCK_DIV_CONFIG2       (UNI_REG_BASE_PMU_CONFIG + 0x88)
#define PMU_CFG_SOURCE_SEL0             (UNI_REG_BASE_PMU_CONFIG + 0x8C)
#define PMU_CFG_PIN_FUNCTION_SEL0       (UNI_REG_BASE_PMU_CONFIG + 0x90)
#define PMU_CFG_PIN_FUNCTION_SEL1       (UNI_REG_BASE_PMU_CONFIG + 0x94)
#define PMU_CFG_PIN_FUNCTION_SEL2       (UNI_REG_BASE_PMU_CONFIG + 0x98)
#define PMU_CFG_IO_IE_SEL               (UNI_REG_BASE_PMU_CONFIG + 0x9c)
#define PMU_CFG_SRAM_GATE_ADDR          (UNI_REG_BASE_PMU_CONFIG + 0x100)
#define PMU_CFG_CLK_GATE                (UNI_REG_BASE_PMU_CONFIG + 0x104)
#define PMU_CFG_SOURCE_SEL1             (UNI_REG_BASE_PMU_CONFIG + 0x108)

// mcu config
#define MCU_CFG_MEPG_CLD_RST_NORM       (UNI_REG_BASE_MCU_CONFIG + 0x00)
#define MCU_CFG_MEPG_CLD_RST_1SET       (UNI_REG_BASE_MCU_CONFIG + 0x04)
#define MCU_CFG_MEPG_CLD_RST_1CLR       (UNI_REG_BASE_MCU_CONFIG + 0x08)
#define MCU_CFG_MEPG_HOT_RST_NORM       (UNI_REG_BASE_MCU_CONFIG + 0x0C)
#define MCU_CFG_MEPG_HOT_RST_1SET       (UNI_REG_BASE_MCU_CONFIG + 0x10)
#define MCU_CFG_MEPG_HOT_RST_1CLR       (UNI_REG_BASE_MCU_CONFIG + 0x14)
#define MCU_CFG_MEPG_CLK_INHIBIT_NORM   (UNI_REG_BASE_MCU_CONFIG + 0x18)
#define MCU_CFG_MEPG_CLK_INHIBIT_1SET   (UNI_REG_BASE_MCU_CONFIG + 0x1C)
#define MCU_CFG_MEPG_CLK_INHIBIT_1CLR   (UNI_REG_BASE_MCU_CONFIG + 0x20)
#define MCU_CFG_DTO0_CONFIG             (UNI_REG_BASE_MCU_CONFIG + 0x24)
#define MCU_CFG_DTO1_CONFIG             (UNI_REG_BASE_MCU_CONFIG + 0x28)
#define MCU_CFG_CLK_GATE                (UNI_REG_BASE_MCU_CONFIG + 0x2C)
#define MCU_CFG_CHIP_ID                 (UNI_REG_BASE_MCU_CONFIG + 0x30)
#define MCU_CFG_CLOCK_DIV_CONFIG0       (UNI_REG_BASE_MCU_CONFIG + 0x80)
#define MCU_CFG_CLOCK_DIV_CONFIG1       (UNI_REG_BASE_MCU_CONFIG + 0x84)
#define MCU_CFG_SOURCE_SEL              (UNI_REG_BASE_MCU_CONFIG + 0x88)
#define MCU_CFG_DW_SPI_CONFIG_ADDR      (UNI_REG_BASE_MCU_CONFIG + 0x8C)
#define MCU_CFG_DW_SPI_FLASH_ADDR       (UNI_REG_BASE_MCU_CONFIG + 0x90)

// Base Address : xip
#define CONFIG_FLASH_XIP_BASE      0x10200000



#define readl(addr) ({ unsigned int __v = (*(volatile unsigned int *) (addr)); __v; })
#define writel(b,addr) (void)((*(volatile unsigned int *) (addr)) = (b))
#define ARRAY_SIZE(x) (sizeof(x) / sizeof((x)[0]))

#endif
