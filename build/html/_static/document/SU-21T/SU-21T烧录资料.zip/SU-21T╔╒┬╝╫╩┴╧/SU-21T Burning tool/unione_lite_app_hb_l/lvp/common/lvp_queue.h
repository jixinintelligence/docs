/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : lvp_queue.h
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/

#ifndef __LVP_QUEUE_H__
#define __LVP_QUEUE_H__

#define __LVP_QUEUE_SUPPORT_BUFFER__

typedef struct {
    int tail;      // next write index
    int head;      // next read index, if back == front, the queue is empty
    unsigned char *buffer;
    int size;
    int member_size;
    char isfull;
} LVP_QUEUE;

void LvpQueueInit(LVP_QUEUE *queue, unsigned char *buffer, int size, int member_size);
int LvpQueuePut(LVP_QUEUE *queue, const unsigned char *value);
int LvpQueueGet(LVP_QUEUE *queue, unsigned char *value);
int LvpQueueGetCapacity(LVP_QUEUE *queue);
int LvpQueueGetDataNum(LVP_QUEUE *queue);
int LvpQueueIsEmpty(LVP_QUEUE *queue);
int LvpQueueIsFull(LVP_QUEUE *queue);

#ifdef __LVP_QUEUE_SUPPORT_BUFFER__

int LvpQueuePutBuffer(LVP_QUEUE *queue, const unsigned int *buffer, int size);
int LvpQueueGetBuffer(LVP_QUEUE *queue, unsigned int *buffer, int size);
int LvpQueuePeekBuffer(LVP_QUEUE *queue, unsigned int *buffer, int size);

int LvpQueueGetFreeSize(LVP_QUEUE *queue);
int LvpQueueGetDataSize(LVP_QUEUE *queue);

#endif

#endif /* __LVP_QUEUE_H__ */
