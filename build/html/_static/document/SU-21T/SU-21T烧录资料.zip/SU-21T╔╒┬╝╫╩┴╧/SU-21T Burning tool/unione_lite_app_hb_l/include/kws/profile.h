/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : profile.h
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/
/**
 * @file profile.h
 * @brief Declare variables for profiling
 * @details
 * @authors Li Peng
 * @copyright 2014-2020 Unisound AI Technology Co., Ltd. All rights reserved.
 */

#ifndef PLAT_SYS_PROFILE_H_
#define PLAT_SYS_PROFILE_H_

#include "osal/osal-time.h"
#include "sys_typedefs.h"
#ifdef PROFILE
extern int64_t g_fep_time;
extern int64_t g_fep_fft_time;
extern int64_t g_fep_mvn_time;
extern int64_t g_fep_mvn1_time;
extern int64_t g_fep_mvn2_time;
extern int64_t g_fep_bank_time;
extern int64_t g_fep_log_time;
extern int64_t g_fep_win_time;
extern int64_t g_fep_pre_time;
extern int64_t g_nn_time;
extern int64_t g_matrix_time;
extern int64_t g_normalize_time;
extern int64_t g_nn_relu_time;
extern int64_t g_nn_cast_time;
extern int64_t g_nn_trans_time;
extern int64_t g_nn_vector_time;
extern int64_t g_nn_bias_time;
extern int64_t g_nn_mem_time;
extern int64_t g_nn_mov_time;
extern int64_t g_nn_cast_32_to_16;
extern int64_t g_nn_cast_32_to_8;
extern int64_t g_nn_cast_32_to_float;
extern int64_t g_nn_cast_16_to_8;
extern int64_t g_decoder_time;
extern int64_t g_decoder_rank_time;
extern int64_t g_decoder_prop_token_time;
extern int64_t g_kws_feature_time;
extern int64_t g_decoder_insert_token_time;
extern int64_t g_profile_new_latnode_time;
extern int64_t g_profile_mark_tokens_path_time;
extern int64_t g_profile_set_token_stamp_zero_time;
extern int64_t g_profile_get_free_token_time;
extern int64_t g_decoder_norm_frame_score_time;
extern int64_t g_decoder_prop_token_time;
extern int64_t g_decoder_update_score_time;
extern int64_t g_decoder_prop_fst_layer_time;
extern int64_t g_profile_get_grammar_arc_time;
extern int64_t g_profile_get_osym_time;
extern int64_t g_profile_update_silence_time;
extern int64_t g_profile_insert_token_in_propfst_time;
extern int64_t g_profile_gen_isym_time;
extern int64_t g_decoder_insert_token_in_prop_token_time;
extern int64_t g_decoder_time_of_time_time;
extern int64_t g_profile_get_grammar_arc_count;
extern int64_t g_profile_insert_token_in_propfst_count;
extern int64_t g_decoder_insert_token_in_prop_token_count;
extern int64_t g_profile_update_silence_count;
#define PROFILE_START_TIME OsalTimeGetUs(&start_time);
#define PROFILE_END_TIME(t) \
  OsalTimeGetUs(&end_time); \
  (t) += OsalTimeDiff(&end_time, &start_time);
#else  // PROFILE
#define PROFILE_START_TIME
#define PROFILE_END_TIME(t)
#endif  // PROFILE

#endif  // PLAT_SYS_PROFILE_H_
