/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : misc.h
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/
#ifndef __SCPU_MISC__
#define __SCPU_MISC__

#include <spl/spl.h>

/*
 *	return value : 0 success, -1 failed
 */
int get_dsk(unsigned char *buf, int len);

/*
 *  let cache work
 */
void uni_cache_init(void);

/*
 * load uboot stage1
 */
int load_uboot_stage1(void);

/*
 * get chipname
 */
int get_chipname(void);

#define NNNA 'A'
#define NNNB 'B'
#define NNNC 'C'

/*
 * get chipversion
 */
int get_chipversion(void);

/*
 * Simultaneous output to uart and usb
 */

int logger(const char *fmt, ...);

/*
 * get a char from uart or usb, auto select
 */
int auto_getchar(void);

/*
 * send a char to uart or usb, auto select
 */
int auto_putchar(char value);

/*
 * Virtual address to dma address
 */
unsigned int virt_to_dma(void *addr);

/*
 * reinit boot info
 */
extern struct boot_info boot_info_s2;
void bootinfo_init(void);

/*
 * Rom 从串口启动时，该接口用于获取 stage2 应该配置的波特率
 * return value : 波特率的值，0 表示不修改串口波特率的配置(沿用之前的波特率)
 */
unsigned int get_baudrate_in_boot_mode(void);

/**
 * @brief 使能模拟参数更新功能.
 * 要想配置模拟参数，需要先调用该函数
 */
void uni_analog_config_update_enable(void);

#endif
