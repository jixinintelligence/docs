/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : uni_dcache.h
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/
#ifndef __UNI_DCACHE_H__
#define __UNI_DCACHE_H__

#include <soc.h>
#include <common.h>

/**
 * @brief 使能 dcache
 */
void uni_dcache_enable(void);

/**
 * @brief 关闭 dcache
 */
void uni_dcache_disable (void);

/**
 * @brief 刷新 cache 中所有的脏数据到内存
 */
void uni_dcache_clean(void);

/**
 * @brief 无效所有 cache 中的数据
 */
void uni_dcache_invalid(void);

/**
 * @brief 刷新 cache 的脏数据到内存, 并无效 cache 中的数据
 */
void uni_dcache_clean_invalid(void);

/**
 * @brief 根据给定的地址和大小，无效 cache 中的数据
 *
 * @param addr 起始地址 需要16字节对齐
 * @param dsize 大小 需要16字节对齐
 */
void uni_dcache_invalid_range (uint32_t *addr, int32_t dsize);

/**
 * @brief 根据给定的地址和大小，刷新 cache 中的数据
 *
 * @param addr 起始地址 需要16字节对齐
 * @param dsize 大小 需要16字节对齐
 */
void uni_dcache_clean_range (uint32_t *addr, int32_t dsize);

/**
 * @brief 根据给定的地址和大小，刷新和无效 cache 中的数据
 *
 * @param addr 起始地址 需要16字节对齐
 * @param dsize 大小 需要16字节对齐
 */
void uni_dcache_clean_invalid_range(uint32_t *addr, int32_t dsize);

/**
 * @brief 使能 dcache 信息统计
 */
void uni_dcache_enable_profile(void);

/**
 * @brief 关闭 dcache 信息统计
 */
void uni_dcache_disable_profile(void);

/**
 * @brief dcache 信息统计数据清零
 */
void uni_dcache_reset_profile(void);

/**
 * @brief 获取 dcache 命中次数
 *
 * @return uint32_t 命中次数
 */
uint32_t uni_dcache_get_access_time(void);

/**
 * @brief 获取 dcache 不命中次数
 *
 * @return uint32_t 不命中次数
 */
uint32_t uni_dcache_get_miss_time(void);

#endif
