/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : uni_timer.h
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/
#ifndef __UNI_TIMER_H__
#define __UNI_TIMER_H__
/** @addtogroup TIMER
@{*/
/**
 * @brief 定时器模式
 */
typedef enum {
    UNI_TIMER_MODE_SINGLE,    ///< 单次模式
    UNI_TIMER_MODE_CONTINUE,  ///< 连续模式
} UNI_TIMER_MODE;

/**
 * @brief 获取当前时间(us)
 *
 * @return unsigned long long 当前时间
 */
unsigned long long uni_get_time_us(void);

/**
 * @brief 获取当前时间(ms)
 *
 * @return unsigned int 当前时间
 */
unsigned int uni_get_time_ms(void);

/**
 * @brief 基于某一时间，获取相对时间
 *
 * @param base 时间基值
 * @return unsigned int 相对时间
 */
unsigned int uni_get_timer(unsigned int base);

/**
 * @brief 注册一个软定时器
 *
 * @param fun 定时回调
 * @param timeout_ms 定时时间
 * @param priv 回调参数
 * @param mode 定时器模式
 * @retval -1 成功
 * @retval timer_id 软定时器id
 */
int uni_timer_register(int (*fun)(void*), int timeout_ms, void *priv, UNI_TIMER_MODE mode);

/**
 * @brief 注销软定时器
 *
 * @param timer_id 软定时器id
 * @retval 注销是否成功
 */
int uni_timer_unregister(int timer_id);

/**
 * @brief 重置软定时器初始时间
 *
 * @param timer_id 软定时器id
 * @param timeout_ms 定时时间
 * @retval 重置是否成功
 */
int uni_timer_reset_time(int timer_id, int timeout_ms);

#endif
