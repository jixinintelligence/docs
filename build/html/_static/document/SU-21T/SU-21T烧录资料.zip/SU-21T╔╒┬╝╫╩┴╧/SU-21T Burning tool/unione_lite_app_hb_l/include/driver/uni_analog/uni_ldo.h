/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : uni_ldo.h
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/
#ifndef __UNI_LDO_H__
#define __UNI_LDO_H__

/**
 * @brief ldo fla使能开关
 *
 * @param enable 0:关 1:开
 *
 * @return int 设置是否成功
 * @retval  0 成功
 * @retval -1 失败
 */
int uni_analog_set_ldo_fla_enbale(unsigned int enable);

/**
 * @brief ldo fla 输出电压设置
 *
 * @param trim  0:1.8V
 *              1:1.775V
 *              2:1.75V
 *              3:1.725V
 *              4:1.7V
 *              5:1.675V
 *              6:1.65V
 *              7:1.625V
 *              8:2.0V
 *              9:1.975V
 *             10:1.95V
 *             11:1.925V
 *             12:1.9V
 *             13:1.875V
 *             14:1.85V
 *             15:1.825V
 *
 * @return int 设置是否成功
 * @retval  0 成功
 * @retval -1 失败
 */
int uni_analog_set_ldo_fla_trim(unsigned int trim);

/**
 * @brief ldo ana exbypass
 *
 * @param exbypass 0:默认， 1:允许soc给出强制bypass信号
 *
 * @return int 设置是否成功
 * @retval  0 成功
 * @retval -1 失败
 */
int uni_analog_set_ldo_ana_exbypass(unsigned int bypass);

/**
 * @brief ldo ana bypass
 *
 * @param exbypass 0:soc给的bypass信号， 1:oc给出强制bypass信号
 *
 * @return int 设置是否成功
 * @retval  0 成功
 * @retval -1 失败
 */
int uni_analog_set_ldo_ana_bypass(unsigned int bypass);

/**
 * @brief ldo ana 输出电压设置
 *
 * @param trim  0: 0.9V
 *              1: 0.925V
 *              2: 0.95V
 *              3: 0.975V
 *             4-8: 0.7V
 *              9: 0.725V
 *             10: 0.75V
 *             11: 0.775V
 *             12: 0.8V
 *             13: 0.825V
 *             14: 0.85V
 *             15: 0.875V
 *
 * @return int 设置是否成功
 * @retval  0 成功
 * @retval -1 失败
 */
int uni_analog_set_ldo_ana_trim(unsigned int trim);

/**
 * @brief ldo dig exbypass
 *
 * @param exbypass 0:默认， 1:允许soc给出强制bypass信号
 *
 * @return int 设置是否成功
 * @retval  0 成功
 * @retval -1 失败
 */
int uni_analog_set_ldo_dig_exbypass(unsigned int bypass);

/**
 * @brief ldo dig bypass
 *
 * @param exbypass 0:默认, 1:oc给出强制bypass信号
 *
 * @return int 设置是否成功
 * @retval  0 成功
 * @retval -1 失败
 */
int uni_analog_set_ldo_dig_bypass(unsigned int bypass);

/**
 * @brief ldo dig dummyload开关
 *
 * @param enable 0:正常工作, 1:打开dummyload 增加内部消耗
 *
 * @return int 设置是否成功
 * @retval  0 成功
 * @retval -1 失败
 */
int uni_analog_set_ldo_dig_dummyload(unsigned int enable);

/**
 * @brief ldo dig 输出电压设置
 *
 * @param trim  0: 0.950V
 *              1: 0.924V
 *              2: 0.897V
 *              3: 0.871V
 *              4: 0.845V
 *              5: 0.819V
 *              6: 0.792V
 *              7: 0.766V
 *              8: 0.740V
 *              9: 0.714V
 *             10: 0.687V
 *             11-15: 0.661V
 *
 * @return int 设置是否成功
 * @retval  0 成功
 * @retval -1 失败
 */
int uni_analog_set_ldo_dig_trim(unsigned int trim);

/**
 * @brief 获取ldo fla bypass状态
 *
 * @return int
 * @retval 0 flash 有ldo_fla供电1.8V
 * @retval 1 外部电压<=2V, flash供电由外部直通
 */
int uni_analog_get_ldo_fla_bypass(void);

/**
 * @brief 获取ldo core bypass状态
 *
 * @return int
 * @retval 0  ldo_ana和ldo_dig都工作，输出0.9V
 * @retval 1  ldo_ana和ldo_dig都进入Bypass模式，外部供电0.9V直通内核
 */
int uni_analog_get_ldo_core_bypass(void);

/**
 * @brief 获取vadd12 ov10 状态
 *
 * @return int
 * @retval 0 判断输入电源是0.9V
 * @retval 1 判断输入电源是1.2V
 */
int uni_analog_get_ldo_vdd12_ov10(void);
#endif
