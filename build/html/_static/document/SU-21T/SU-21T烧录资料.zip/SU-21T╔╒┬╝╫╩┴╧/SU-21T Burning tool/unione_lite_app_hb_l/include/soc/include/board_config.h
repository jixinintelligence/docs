/**************************************************************************
 * Copyright (C) 2012-2021  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : board_config.h
 * Author      : yzs.unisound.com
 * Date        : 2021.03.01
 *
 **************************************************************************/

#ifndef __BOARD_CONFIG_H__
#define __BOARD_CONFIG_H__

#include <autoconf.h>
#include <base_addr.h>
#include <soc_config.h>

#define CONFIG_BOARD_PATH           boards/unisound/us513_demo_v1

#define CONFIG_SERIAL_BAUD_RATE 115200
#define CONFIG_CLOCK_UART 24576000
#define CONFIG_SPL_UART_CLKDIV 7  /* (CONFIG_CLOCK_UART) / (16 * baudrate) */
#define CONFIG_SPL_UART_CLKDLF 12  /* (CONFIG_CLOCK_UART % (16 * baudrate) * 1.0) / (16 * baudrate) * (1 << 4) */

/* Environment for SDMMC boot */
#if defined(CONFIG_ENV_IS_IN_MMC) && !defined(CONFIG_ENV_OFFSET)
#define CONFIG_SYS_MMC_ENV_DEV		0	/* device 0 */
#define CONFIG_ENV_OFFSET		512	/* just after the MBR */
#endif

/* Environment for SPI boot */
#if defined(CONFIG_ENV_IS_IN_SPI_FLASH) && !defined(CONFIG_ENV_OFFSET)
#define CONFIG_ENV_OFFSET		0x00100000
#define CONFIG_ENV_SECT_SIZE		(64 * 1024)
#endif

/* Environment for nvram boot */
#ifdef CONFIG_ENV_IS_IN_NVRAM
#define CONFIG_ENV_ADDR             (CONFIG_SYS_MALLOC_BASE + CONFIG_SYS_MALLOC_LEN)
#endif

#ifndef CONFIG_BOOT_TOOL
#define CONFIG_BOOTCOMMAND  ""
#endif

/*
 * Designware SPI support
 */
#ifdef CONFIG_CMD_SPI
#define CONFIG_DEFAULT_SPI_BUS		0
#define CONFIG_DEFAULT_SPI_CS		0
#endif

/* SPI FLASH */
#define CONFIG_FLASH_SPI_CLK_SRC        (24576000/2)    /* 12.5MHz */
#define CONFIG_SF_DEFAULT_CLKDIV        2            /* 分频数必须为偶数且非0 */
#define CONFIG_SF_DEFAULT_SAMPLE_DELAY  1
#define CONFIG_SF_DEFAULT_SPEED         (CONFIG_FLASH_SPI_CLK_SRC / CONFIG_SF_DEFAULT_CLKDIV)

#define CONFIG_SF_DEFAULT_BUS           0
#define CONFIG_SF_DEFAULT_MODE          0x800
#define CONFIG_SF_DMA_XFER              0x800
#define CONFIG_SF_DEFAULT_CS            0

/*GENERAL_SPI*/
#define CONFIG_GENERAL_SPI_CLK_SRC      (24576000/2)
#define CONFIG_GENERAL_SPI_BUS_SN       0

/* WDT */
#define CONFIG_WDT_SYS_CLK  12500000

/* load uboot stage1 */
#define CONFIG_UBOOT_STAGE1_OFFS  (0x100000  )
#define CONFIG_UBOOT_STAGE1_SIZE  (0x10000   )
#define CONFIG_UBOOT_STAGE1_SRAM  (0xa0100000)

#endif	/* __BOARD_CONFIG_H__ */
