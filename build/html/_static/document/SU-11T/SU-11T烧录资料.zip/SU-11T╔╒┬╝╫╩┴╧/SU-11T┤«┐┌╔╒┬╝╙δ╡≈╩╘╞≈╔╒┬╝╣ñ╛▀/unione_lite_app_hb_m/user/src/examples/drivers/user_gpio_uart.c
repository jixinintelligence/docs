#include "user_gpio_uart.h"
#include "uni_hal_timer.h"
#include "irqn.h"
#include "user_gpio.h"
#include "uni_types.h"

#define UART_GPIO_TAG "uart_gpio"

typedef struct UartRxBufferType {
  unsigned char writeindex;
  unsigned char readindex;
  unsigned char buffer[GPIOUartRxBufferSize];
} UartRxBufferType;

typedef enum GPIOUartRxStateType {
  GPIOUartRxState_Idle,
  GPIOUartRxState_ReadingStart,
  GPIOUartRxState_ReadingData,
  GPIOUartRxState_ReadingStop,
} GPIOUartRxStateType;

static unsigned int UartRxSampleTimeFirst;
static unsigned int UartRxSampleTimePeriod;
static UartRxBufferType UartRxBuffer;
volatile GPIOUartRxStateType GPIOUartRxState;
static unsigned int GPIOUartErrorFlag;
static unsigned int UartTxSampleTimePeriod;

int total_cnt = 0;

static void GPIOUartRxTimerIrqHandler(TIMER_INDEX TimerIdx);
static void GPIOUartTxTimerHandler(TIMER_INDEX TimerIdx);
static void GPIOUartRxGPIOIrqHandle(GPIO_NUMBER num, uni_bool is_high);

static void GPIOUartRxIoIrqSet() {
#if 0
     NVIC_EnableIRQ(Gpio_IRQn);
     if(GPIO_UART_RX > (1<<8)){
	    GPIO_RegOneBitSet(GPIO_A_IE, GPIO_UART_RX);
	    GPIO_RegOneBitClear(GPIO_A_OE, GPIO_UART_RX);
	    GPIO_RegOneBitSet(GPIO_A_PU, GPIO_UART_RX);
	    GPIO_RegOneBitClear(GPIO_A_PD, GPIO_UART_RX);
	 }else{
        GPIO_RegOneBitSet(GPIO_B_IE, GPIO_UART_RX);
	    GPIO_RegOneBitClear(GPIO_B_OE, GPIO_UART_RX);
	    GPIO_RegOneBitSet(GPIO_B_PU, GPIO_UART_RX);
	    GPIO_RegOneBitClear(GPIO_B_PD, GPIO_UART_RX);
	 }
#else
  user_gpio_interrupt_enable();
  user_gpio_set_mode(RX_GPIO, GPIO_MODE_IN);
  user_gpio_set_pull_mode(RX_GPIO, GPIO_PULL_UP);

#endif
}
static void GPIOUartRxIoIrqDisable(void) {
  if (GPIO_UART_RX > (1 << 8)) {
    GPIO_INTDisable(GPIO_A_INT, GPIO_UART_RX);
  } else {
    GPIO_INTDisable(GPIO_B_INT, GPIO_UART_RX);
  }
}

static void GPIOUartRxIoIrqEnable(int flag) {
  if (!flag) {
    if (GPIO_UART_RX > (1 << 8)) {
      GPIO_INTEnable(GPIO_A_INT, GPIO_UART_RX, GPIO_NEG_EDGE_TRIGGER);
    } else {
      GPIO_INTEnable(GPIO_B_INT, GPIO_UART_RX, GPIO_NEG_EDGE_TRIGGER);
    }
  } else {
    user_gpio_set_interrupt(RX_GPIO, GPIO_INT_NEG_EDGE,
                            GPIOUartRxGPIOIrqHandle);
  }
}

static void GPIOUartRxTimerIrqDisable() { uni_hal_timer_pause(TIMER5, 1); }

static void GPIOUartRxTimerIrqEnable(unsigned int timer_value) {
  uni_hal_timer_config(TIMER5, timer_value, 1);
  uni_hal_timer_start(TIMER5);
}

static void GPIOUartTxTimerEnable(unsigned int timer_value) {
  uni_hal_timer_config(TIMER6, timer_value, 0);
  uni_hal_timer_start(TIMER6);
}

static void GPIOUartRxGPIOIrqHandle(GPIO_NUMBER num, uni_bool is_high) {
  if (GPIOUartRxState == GPIOUartRxState_Idle) {
    GPIOUartRxState = GPIOUartRxState_ReadingStart;
    GPIOUartRxIoIrqDisable();
    GPIOUartRxTimerIrqEnable(UartRxSampleTimeFirst);
  }
}
#if 0
//unsigned int gpioPinIndex[2] = {0,0};
__attribute__((section(".driver.isr"))) void GpioInterrupt(void)

{
#if 0
	gpioPinIndex[0] = GPIO_INTFlagGet(GPIO_A_INT);
	if(gpioPinIndex[0])
	{
		if(GPIOUartRxState == GPIOUartRxState_Idle)
		{
			GPIOUartRxState = GPIOUartRxState_ReadingStart;
			GPIOUartRxIoIrqDisable();
			GPIOUartRxTimerIrqEnable(UartRxSampleTimeFirst);
			GPIO_INTFlagClear(GPIO_B_INT,gpioPinIndex[0]);
		}

	}

	gpioPinIndex[1] = GPIO_INTFlagGet(GPIO_B_INT);
	if(gpioPinIndex[1])
	{
		if(GPIOUartRxState == GPIOUartRxState_Idle)
		{
			GPIOUartRxState = GPIOUartRxState_ReadingStart;
			GPIOUartRxIoIrqDisable();
			GPIOUartRxTimerIrqEnable(UartRxSampleTimeFirst);
			GPIO_INTFlagClear(GPIO_B_INT,gpioPinIndex[1]);
		}

	}
#else
    //printf("#\n");
    unsigned int value = GPIO_INTFlagGet(GPIO_A_INT);
	if(GPIOUartRxState == GPIOUartRxState_Idle)
	{
		GPIOUartRxState = GPIOUartRxState_ReadingStart;
		GPIOUartRxIoIrqDisable();
		GPIOUartRxTimerIrqEnable(UartRxSampleTimeFirst);
	}
	GPIO_INTFlagClear(GPIO_A_INT,value);
#endif
}
#endif

static void GPIOUartRxBufferInit() {
  UartRxBuffer.readindex = 0;
  UartRxBuffer.writeindex = 0;
}

static int GPIOUartRxBufferWrite(unsigned char data) {
  unsigned int i = (UartRxBuffer.writeindex + 1) % GPIOUartRxBufferSize;
  if (i == UartRxBuffer.readindex) {
    return 0;
  } else {
    UartRxBuffer.buffer[UartRxBuffer.writeindex] = data;
    UartRxBuffer.writeindex = i;
    return 1;
  }
}

int GPIOUartRxBufferRead(unsigned char *data) {
  if (UartRxBuffer.writeindex == UartRxBuffer.readindex) {
    return 0;
  } else {
    *data = UartRxBuffer.buffer[UartRxBuffer.readindex];
    UartRxBuffer.readindex++;
    UartRxBuffer.readindex %= GPIOUartRxBufferSize;
    return 1;
  }
}

static void InitSampleTimeList(unsigned int bandrate) {
#if 1
  unsigned int T = (TimerClkFrequency) / bandrate;

  UartRxSampleTimeFirst = T / 2;  // To Read Start[0]
  UartRxSampleTimePeriod = T;     // To Read Bit0-Bit7 and Stop
  printf("UartRxSampleTimeFirst = %d,UartRxSampleTimePeriod = %d\n",
         UartRxSampleTimeFirst, UartRxSampleTimePeriod);
#else
  UartRxSampleTimeFirst = 10;
  UartRxSampleTimePeriod = 18;
#endif
  // Most of the time, cumulative errors can be ignore ...
}

void GPIOUartRxInit(int bandrate) {
  printf("enter GPIOUartRxInit\n");
  GPIOUartRxIoIrqSet();

  GPIOUartRxBufferInit();
  InitSampleTimeList(bandrate);
  GPIOUartRxState = GPIOUartRxState_Idle;
  GPIOUartErrorFlag = 0;

  GPIOUartRxIoIrqEnable(1);

  uni_hal_timer_init(TIMER5, UartRxSampleTimeFirst, 1,
                     GPIOUartRxTimerIrqHandler);
}

// int debug_cnt0;
// int debug_cnt1;
static void GPIOUartRxTimerIrqHandler(TIMER_INDEX TimerIdx) {
  static int read_cnt;
  static unsigned char read_data;
  int PIN = 0;
  PIN = GPIO_RegOneBitGet(GPIO_A_IN, GPIO_UART_RX);

  if (GPIOUartRxState == GPIOUartRxState_ReadingStart) {
    if (!PIN) {
      // debug_cnt0++;
      GPIOUartRxState = GPIOUartRxState_ReadingData;
      read_data = 0;
      read_cnt = 0;
      uni_hal_timer_config(TIMER5, UartRxSampleTimePeriod, 0);
      uni_hal_timer_start(TIMER5);
    } else {
      // debug_cnt1++;
      GPIOUartErrorFlag |= 1;
      GPIOUartRxTimerIrqDisable();
      GPIOUartRxState = GPIOUartRxState_Idle;
      GPIOUartRxIoIrqEnable(0);
    }
  } else if (GPIOUartRxState == GPIOUartRxState_ReadingData) {
    read_data >>= 1;
    if (PIN) {
      read_data |= 0x80;
    }
    read_cnt++;
    if (read_cnt == 8) {
      GPIOUartRxState = GPIOUartRxState_ReadingStop;
    }
  } else if (GPIOUartRxState == GPIOUartRxState_ReadingStop) {
    if (PIN) {
      // printf("%d\n",read_data);
      // total_cnt++;
      GPIOUartRxTimerIrqDisable();
      GPIOUartRxState = GPIOUartRxState_Idle;
      GPIOUartRxBufferWrite(read_data);
      GPIOUartRxIoIrqEnable(0);
    } else {
      GPIOUartErrorFlag |= 2;
      GPIOUartRxTimerIrqDisable();
      GPIOUartRxState = GPIOUartRxState_Idle;
      GPIOUartRxIoIrqEnable(0);
    }
  }
}

// tx
static volatile unsigned int GPIOUartTxSendBuffer;

static void GPIOUartTxIoInit(void) {
  if (GPIO_UART_TX > (1 << 8)) {
    GPIO_RegOneBitClear(GPIO_A_IE, GPIO_UART_TX);
    GPIO_RegOneBitSet(GPIO_A_OE, GPIO_UART_TX);
    GPIO_RegOneBitSet(GPIO_A_OUT, GPIO_UART_TX);
  } else {
    GPIO_RegOneBitClear(GPIO_B_IE, GPIO_UART_TX);
    GPIO_RegOneBitSet(GPIO_B_OE, GPIO_UART_TX);
    GPIO_RegOneBitSet(GPIO_B_OUT, GPIO_UART_TX);
  }
}

void GPIOUartTxInit(int bandrate) {
  GPIOUartTxIoInit();
  UartTxSampleTimePeriod = TimerClkFrequency / bandrate;
  uni_hal_timer_init(TIMER6, UartTxSampleTimePeriod, 0, GPIOUartTxTimerHandler);
}

void GPIOUartTxSend(unsigned char data) {
#if 1
  GPIOUartTxSendBuffer = data;
  GPIOUartTxSendBuffer <<= 1;
  GPIOUartTxSendBuffer |= 0x00000200;
  GPIOUartTxTimerEnable(UartTxSampleTimePeriod);
  while (GPIOUartTxSendBuffer != 0)
    ;
#else
  GPIOUartTxSendBuffer = data;
  GPIOUartTxSendBuffer |= 0x00000100;             // data+stop
  GPIO_RegOneBitClear(GPIO_A_OUT, GPIO_UART_TX);  // start
  GPIOUartTxTimerEnable(UartTxSampleTimePeriod);
  while (GPIOUartTxSendBuffer != 0)
    ;
#endif
}
static void GPIOUartTxTimerHandler(TIMER_INDEX TimerIdx) {
  if (GPIOUartTxSendBuffer == 0) {
    uni_hal_timer_pause(TIMER6, 1);
    return;
  }
  if (GPIOUartTxSendBuffer & 1) {
    if (GPIO_UART_TX > (1 << 8)) {
      GPIO_RegOneBitSet(GPIO_A_OUT, GPIO_UART_TX);
    } else {
      GPIO_RegOneBitSet(GPIO_B_OUT, GPIO_UART_TX);
    }
  } else {
    if (GPIO_UART_TX > (1 << 8)) {
      GPIO_RegOneBitClear(GPIO_A_OUT, GPIO_UART_TX);
    } else {
      GPIO_RegOneBitClear(GPIO_B_OUT, GPIO_UART_TX);
    }
  }
  GPIOUartTxSendBuffer >>= 1;
}
