/**************************************************************************
 * Copyright (C) 2017-2017  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : hb_i2c.c
 * Author      : yuanshifeng@unisound.com
 * Date        : 2020.04.25
 *
 **************************************************************************/
#include "uni_iot.h"
#include "uni_hal_gpio.h"
#include "uni_hal_i2c.h"
#include "uni_databuf.h"
#include "irqn.h"

#define TAG "hb_i2c"

#define LOG_DEBUG printf
#define IIC_INTERRUPT_MODE 0

#define SLAVE_ADDR   0x2a

#define REC_BUF_LEN 128
DataBufHandle  g_rec_databuf = NULL;
static uint8_t SendBuf[4] = {0x11, 0x22, 0x33, 0x44};
uni_sem_t     i2c_send_done_sem;

#if IIC_INTERRUPT_MODE == 0
static I2C_ErrorState I2C_SlaveSendAndReceive(uint8_t *RecvBuf, uint32_t BufLen,
                                       uint32_t *RecvLen) {
  uint32_t i;
  *RecvLen = 0;
  I2C_SlaveConfig();
  while (!I2C_GetIntFlag());
  I2C_IntClr();
  if (!I2C_IsAddressMatched()) {
    LOG_DEBUG("Address Matched Error\n");
    return ERROR_UNMATCH;
  }
  if (I2C_SlaveReadWriteGet())  //检查发送或者接收状态
  {
    I2C_SendStart();
    for (i = 0; i < sizeof(SendBuf); i++) {
      I2C_SendByte(SendBuf[i]);
      while (!I2C_GetIntFlag())
        ;
      I2C_IntClr();
      if (I2C_ReceiveAcknowledge()) {
        break;
      }
    }
    I2C_SlaveReleaseI2C();
    while (I2C_IsBusy());
    uni_sem_post(i2c_send_done_sem);
  } else {
    RecvBuf[0] = I2C_ReceiveByte();  // dummy read for trigger recv
    for (i = 0; i < BufLen; i++) {
      while (!I2C_GetIntFlag()) {
        if (!I2C_IsBusy()) {
          *RecvLen = i;
          return ERROR_OK;
        }
      };
      I2C_IntClr();
      RecvBuf[i] = I2C_ReceiveByte();
      if (!I2C_IsBusy()) {  // end receive data
        i++;
        break;
      }
    }
    *RecvLen = i;
  }
  return ERROR_OK;
}

static void _hb_i2c_task(void *args) {
  unsigned char *iicRecvBuf = NULL;
  unsigned char ret = 0;
  uint32_t recv_len;

  iicRecvBuf = uni_malloc(REC_BUF_LEN);
  if (iicRecvBuf == NULL) {
    LOG_DEBUG("iicRecvBuf malloc err\n");
  }
  memset(iicRecvBuf, 0, REC_BUF_LEN);

  //初始化I2C slave模式, 设置从设备地址为SLAVE_ADDR, 0x2f为分频系数, 对应clk=100KHz
  if (I2C_Init(0x2B, I2C_PORT_B2_B3, SLAVE_ADDR) != ERROR_OK) {
    LOG_DEBUG("IIC init err\n");
  }
  while (1) {
    // ret = I2C_SlaveReceiveBuffer_fix(iicRecvBuf, IIC_RECV_BUF_SIZE, &recv_len);
    ret = I2C_SlaveSendAndReceive(iicRecvBuf, 1, &recv_len);
    switch (ret) {
      case ERROR_OK:
        if (recv_len > 0) {
          //do recv action
          LOG_DEBUG("recv done, len = %d\n", (int)recv_len);
        } else {
          LOG_DEBUG("send done\n");
        }
        break;

      case ERROR_BUSY:
      case ERROR_TIMEOUT:
      case ERROR_NOACK:
      case ERROR_UNMATCH:
        LOG_DEBUG("IIC init err %d \n", ret);
        break;

      case ERROR_SLAVEMODE:
        break;

      case ERROR_DIV_OVERSTEP:
        break;
    }

  }

  if (iicRecvBuf) {
    uni_free(iicRecvBuf);
  }
  vTaskDelete(NULL);
}

#else
__attribute__((section(".driver.isr"))) void I2C_Interrupt(void) {
  static uint8_t RW_FLAG = 0;
  static uint8_t TX_count = 0;
  char c;
  if (I2C_IsAddressMatched())  //判断该中断是否为地址匹配中断
  {
    if (I2C_SlaveReadWriteGet())  //判断读写标志
    {
      I2C_IntEn(1);  //写一下寄存器（这里定为写中断使能位）清除地址匹配标识，以防出现与地址一样的数据误触发地址匹配中断
      I2C_IntClr();  //清除中断标志位
      RW_FLAG = 1;
      I2C_SendStart();  //配置为发送模式
      TX_count = 0;
      I2C_SendByte(SendBuf[TX_count]);  //发送第一个数据
    } else {
      I2C_IntEn(1);  //写一下寄存器（这里定为写中断使能位）清除地址匹配标识，以防出现与地址一样的数据误触发地址匹配中断
      I2C_IntClr();        //清除中断标志位
      I2C_ReceiveByte();   //清空FIFO
      I2C_ReceiveStart();  //配置为接收模式
      RW_FLAG = 0;
    }
  } else {  //根据之前的读写标志来做出相应的处理
    if (RW_FLAG) {
      if (I2C_ReceiveAcknowledge())  //判断是否收到ACK
      {
        TX_count++;
        I2C_SlaveReleaseI2C();  //释放I2C总线
        I2C_ReceiveByte();      //清空FIFO
        uni_sem_post(i2c_send_done_sem);
      } else {
        TX_count++;
        if (TX_count < sizeof(SendBuf)) {
          I2C_SendByte(SendBuf[TX_count]);
        }
      }
      I2C_IntClr();  //清除中断标志位
    } else {
      c = I2C_ReceiveByte();
      if (g_rec_databuf && (DataBufferGetFreeSize(g_rec_databuf) > 0)) {
        DataBufferWrite(g_rec_databuf, &c, sizeof(c));
      }
      I2C_IntClr();  //清除中断标志位
    }
  }
}

static void _hb_i2c_int_task(void *args) {
  int data_len;
  static char tmp_buf[1] = {0};

  g_rec_databuf = DataBufferCreate(REC_BUF_LEN);
  if (NULL == g_rec_databuf) {
    LOG_DEBUG("i2c alloc recv buf failed\n");
    goto L_END;
  }

  //初始化I2C slave模式, 设置从设备地址为SLAVE_ADDR, 0x2f为分频系数,
  //对应clk=100KHz
  if (I2C_Init(0x2B, I2C_PORT_B2_B3, SLAVE_ADDR) != ERROR_OK) {
    LOG_DEBUG("IIC init err\n");
    goto L_END;
  }
  NVIC_EnableIRQ(I2C_InIRQn);
  I2C_IntEn(1);
  I2C_SlaveConfig();
  while (1) {
    data_len = DataBufferGetDataSize(g_rec_databuf);
    if (data_len <= 0) {
      uni_msleep(10);
      continue;
    }

    if (data_len > sizeof(tmp_buf)) {
      data_len = sizeof(tmp_buf);
    }

    data_len = DataBufferRead(tmp_buf, data_len, g_rec_databuf);
    //do recv action
    LOG_DEBUG("recv done, len = %d, data=0x%x\n", data_len, tmp_buf[0]);
  }
L_END:
  if (g_rec_databuf) {
    DataBufferDestroy(g_rec_databuf);
  }
  vTaskDelete(NULL);
}
#endif

int hb_i2c(void) {
  uni_sem_init(&i2c_send_done_sem, 0);
  // Init SCL and SDA pins
  GPIO_RegOneBitSet(GPIO_B_PU, GPIO_INDEX2);
  GPIO_RegOneBitClear(GPIO_B_PD, GPIO_INDEX2);
  GPIO_RegOneBitSet(GPIO_B_PU, GPIO_INDEX3);
  GPIO_RegOneBitClear(GPIO_B_PD, GPIO_INDEX3);
  GPIO_PortBModeSet(GPIOB2, 0x1);
  GPIO_PortBModeSet(GPIOB3, 0x2);

  uni_pthread_t pid;
  thread_param param;
  param.stack_size = STACK_SMALL_SIZE;
  param.priority   = OS_PRIORITY_NORMAL;
  strncpy(param.task_name, "hb-i2c", sizeof(param.task_name) - 1);
  #if IIC_INTERRUPT_MODE == 0
  uni_pthread_create(&pid, &param, _hb_i2c_task, NULL);
  #else
  uni_pthread_create(&pid, &param, _hb_i2c_int_task, NULL);
  #endif
  return 0;
}
