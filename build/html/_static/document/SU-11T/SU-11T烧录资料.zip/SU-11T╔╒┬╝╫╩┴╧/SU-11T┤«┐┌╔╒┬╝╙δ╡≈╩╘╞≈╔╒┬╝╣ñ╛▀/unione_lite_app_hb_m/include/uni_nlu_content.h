#ifndef INC_UNI_NLU_CONTENT_H_
#define INC_UNI_NLU_CONTENT_H_

typedef struct {
  uni_u32 key_word_hash_code; /* 存放识别词汇对应的hashcode */
  uni_u8  nlu_content_str_index; /* 存放nlu映射表中的索引，实现多个识别词汇可对应同一个nlu，暂支持256条，如果不够换u16 */
  char    *hash_collision_orginal_str /* 类似Java String equal，当hash发生碰撞时，赋值为识别词汇，否则设置为NULL */;
} uni_nlu_content_mapping_t;

enum {
  eCMD_wakeup_uni,
  eCMD_exitUni,
  eCMD_TurnOn,
  eCMD_TurnOff,
  eCMD_BrightnessUp,
  eCMD_BrightnessOff,
  eCMD_starttimer,
  eCMD_volup,
  eCMD_voldown,
};

const char* const g_nlu_content_str[] = {
[eCMD_wakeup_uni] = "{\"asr\":\"你好小智\",\"cmd\":\"wakeup_uni\",\"pcm\":\"[103, 104, 105]\"}",
[eCMD_exitUni] = "{\"asr\":\"退下\",\"cmd\":\"exitUni\",\"pcm\":\"[106]\"}",
[eCMD_TurnOn] = "{\"asr\":\"打开台灯\",\"cmd\":\"TurnOn\",\"pcm\":\"[108]\"}",
[eCMD_TurnOff] = "{\"asr\":\"关闭台灯\",\"cmd\":\"TurnOff\",\"pcm\":\"[109]\"}",
[eCMD_BrightnessUp] = "{\"asr\":\"调亮一点\",\"cmd\":\"BrightnessUp\",\"pcm\":\"[110]\"}",
[eCMD_BrightnessOff] = "{\"asr\":\"调暗一点\",\"cmd\":\"BrightnessOff\",\"pcm\":\"[111]\"}",
[eCMD_starttimer] = "{\"asr\":\"启动定时器\",\"cmd\":\"starttimer\",\"pcm\":\"[112]\"}",
[eCMD_volup] = "{\"asr\":\"增大音量\",\"cmd\":\"volup\",\"pcm\":\"[113]\"}",
[eCMD_voldown] = "{\"asr\":\"减小音量\",\"cmd\":\"voldown\",\"pcm\":\"[114]\"}",
};

/*TODO perf sort by hashcode O(logN), now version O(N)*/
const uni_nlu_content_mapping_t g_nlu_content_mapping[] = {
  {2835566009U/*你好小智*/, eCMD_wakeup_uni, NULL},
  {2497873774U/*退下*/, eCMD_exitUni, NULL},
  {2389288886U/*再见*/, eCMD_exitUni, NULL},
  {3402919336U/*打开台灯*/, eCMD_TurnOn, NULL},
  {3269676220U/*请开灯*/, eCMD_TurnOn, NULL},
  {2438769644U/*开灯*/, eCMD_TurnOn, NULL},
  {3196940412U/*打开灯*/, eCMD_TurnOn, NULL},
  {516300443U/*我回来了*/, eCMD_TurnOn, NULL},
  {2461846363U/*关闭台灯*/, eCMD_TurnOff, NULL},
  {3220401906U/*请关灯*/, eCMD_TurnOff, NULL},
  {2389495330U/*关灯*/, eCMD_TurnOff, NULL},
  {1492864401U/*睡觉了*/, eCMD_TurnOff, NULL},
  {631442226U/*关上灯*/, eCMD_TurnOff, NULL},
  {3353272135U/*我出去了*/, eCMD_TurnOff, NULL},
  {1648810031U/*调亮一点*/, eCMD_BrightnessUp, NULL},
  {175714954U/*亮一点*/, eCMD_BrightnessUp, NULL},
  {3455764346U/*调暗一点*/, eCMD_BrightnessOff, NULL},
  {1982669269U/*暗一点*/, eCMD_BrightnessOff, NULL},
  {2397078785U/*启动定时器*/, eCMD_starttimer, NULL},
  {642591547U/*增大音量*/, eCMD_volup, NULL},
  {182008939U/*减小音量*/, eCMD_voldown, NULL},
};

#endif
