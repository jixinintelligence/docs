/*
___         _______                                 _______ ___________________
   |       |       |       :       :       :       |       |       :       |
   | start | bit 0 | bit 1 : bit 2 : bit 3 : bit 4 | bit 5 | bit 6 : bit 7 |
stop
   |_______|       |_______:_______:_______:_______|       |_______:_______|

*/
/*
    readme: 8bit,no parity,1 stopbit
*/
#ifndef _GPIO_UART_RX_H_
#define _GPIO_UART_RX_H_

#include "uni_hal_gpio.h"
#include "uni_hal_pwm.h"
#include "uni_hal_timer.h"

//#define UART_TIMER      eTIMER5
#define GPIO_UART_RX (GPIO_INDEX25)
#define GPIO_UART_TX (GPIO_INDEX26)
#define RX_GPIO      (GPIO_NUM_A25)

#define TimerClkFrequency (1000000)

#define GPIOUartRxBufferSize (128)
#if (GPIOUartRxBufferSize & (GPIOUartRxBufferSize - 1))
#warning[GPIOUartRxBufferSize] SHOULD BE POWER OF 2 FOR OPTIMISING
#endif
#if (GPIOUartRxBufferSize > 256)
#error[GPIOUartRxBufferSize] SHOULD <= 256
#endif

void GPIOUartRxInit(int bandrate);

int GPIOUartRxBufferRead(unsigned char *data);
void GPIOUartTxInit(int bandrate);
void GPIOUartTxSend(unsigned char data);

#endif
