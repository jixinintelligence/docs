/**************************************************************************
 * Copyright (C) 2020-2020  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : user_gpio_uart.c
 * Author      : yuanshifeng@unisound.com
 * Date        : 2020.04.21
 *
 **************************************************************************/
#include "user_gpio_uart.h"
#include "user_gpio.h"

#define TAG "gpio_uart_example"

static void _uart_start_process(void *args) {
  unsigned char data = 0xff;
  printf("enter _uart_start_process\n");
  GPIOUartRxInit(4800);
  GPIOUartTxInit(4800);
  while (1) {
    uni_msleep(1000);
    GPIOUartTxSend(data);
    while (GPIOUartRxBufferRead(&data)) {
      printf("data: 0x%x\n", data);
    }
  }
}

int hb_gpio_uart(void) {
  thread_param param;
  uni_pthread_t pid;
  uni_memset(&param, 0, sizeof(param));
  param.stack_size = STACK_SMALL_SIZE;
  param.priority = OS_PRIORITY_HIGH;
  uni_strncpy(param.task_name, "uart_process", sizeof(param.task_name) - 1);
  if (0 != uni_pthread_create(&pid, &param, _uart_start_process, NULL)) {
    LOGE(TAG, "create thread failed");
    return E_FAILED;
  }
  uni_pthread_detach(pid);
  return E_OK;
}
