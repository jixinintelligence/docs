/**************************************************************************
 * Copyright (C) 2017-2017  Unisound
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 **************************************************************************
 *
 * Description : user_uart.c
 * Author      : wufangfang@unisound.com
 * Date        : 2020.04.14
 *
 **************************************************************************/
#include "user_uart.h"
#include "user_config.h"
#include "uni_uart.h"

#define TAG "user_uart"

static UartHandle g_uart_handle[UNI_UART_CNT] = {0};

int user_uart_init(int id, int pinmode, int baudrate, int data_bits,
                   int stop_bits, int parity, _user_uart_recv cb_recv) {
  UartConfig config;
  if (UNI_UART_CNT <= id) {
    LOGE(TAG, "only support %d device. uart%d is invalid", UNI_UART_CNT, id);
    return -1;
  }
#if USE_UNIONE_PROTOCOL || USE_SAMPLE_PROTOCOL
  if (USER_UART_DEVICE_NUM == id) {
    LOGE(TAG, "USER_UART and UNI_UART cannot be same device.");
    return -1;
  }
#endif
  switch (id) {
    case 0:
      config.device = UNI_UART0;
      break;
    case 1:
      config.device = UNI_UART1;
      break;
    default:
      LOGE(TAG, "invalid uart id %d", id);
      return -1;
  }
  switch (pinmode) {
    case 0:
      config.mode = UNI_MODE0;
      break;
    case 1:
      config.mode = UNI_MODE1;
      break;
    case 2:
      config.mode = UNI_MODE2;
      break;
    default:
      LOGE(TAG, "invalid uart pinmode %d", pinmode);
      return -1;
  }
  switch (parity) {
    case 0:
      config.parity = UNI_PARITY_NONE;
      break;
    case 1:
      config.parity = UNI_PARITY_ODD;
      break;
    case 2:
      config.parity = UNI_PARITY_EVEN;
      break;
    default:
      LOGE(TAG, "invalid uart parity %d", parity);
      return -1;
  }
  switch (baudrate) {
    case 4800:
      config.speed = UNI_B_4800;
      break;
    case 9600:
      config.speed = UNI_B_9600;
      break;
    case 19200:
      config.speed = UNI_B_19200;
      break;
    case 38400:
      config.speed = UNI_B_38400;
      break;
    case 57600:
      config.speed = UNI_B_57600;
      break;
    case 115200:
      config.speed = UNI_B_115200;
      break;
    default:
      LOGE(TAG, "invalid uart baudrate %d", baudrate);
      return -1;
  }
  switch (stop_bits) {
    case 1:
      config.stop = UNI_ONE_STOP_BIT;
      break;
    case 2:
      config.stop = UNI_TWO_STOP_BIT;
      break;
    default:
      LOGE(TAG, "invalid uart stop_bits %d", stop_bits);
      return -1;
  }
  config.data_bit = data_bits;

  if (NULL == (g_uart_handle[id] = UartInitialize(&config, (RecvUartDataHandler)cb_recv))) {
    LOGE(TAG, "UartInitialize failed. uart%d", id);
    return -1;
  }
  return 0;
}

void user_uart_final(int id) {
  UartFinalize(g_uart_handle[id]);
}

int user_uart_send(int id, const char *buf, int len) {
  if (NULL == g_uart_handle[id]) {
    LOGE(TAG, "g_uart_handle[%d] is NULL.", id);
    return -1;
  }
  return UartWrite((char *)buf, len, g_uart_handle[id]);
}

