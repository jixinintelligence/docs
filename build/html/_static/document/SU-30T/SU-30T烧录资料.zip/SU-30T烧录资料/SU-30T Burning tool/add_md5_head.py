import os
import sys
import hashlib
CHECKMD5_BIN = ["app.bin", "dsp.bin", "module.bin", "pcm.bin"]

if (len(sys.argv) < 2):
    print ("Usage: " + sys.argv[0] + "CHECKMD5_BIN name")
else:
    bin_name = sys.argv[1]
    lines = []
    if (os.path.basename(bin_name) in CHECKMD5_BIN):
        (filename, extension) = os.path.splitext(bin_name)
        out_file = os.path.dirname(os.path.abspath(__file__)) + os.path.sep + os.path.basename(filename + '_md5.bin')
        print out_file
    else:
        print(bin_name + " not in checkmd5 list")
        sys.exit()

    out_fd = open(out_file, "wb")
    with open(bin_name, "rb") as fp:
        content = fp.read()
        file_md5 = hashlib.md5(content).hexdigest()
        lines.append(file_md5 + bytearray(256 - 32) + content)
        out_fd.writelines(lines)
    out_fd.close()
